package fr.niferx.lucky.registry;

import fr.niferx.lucky.LuckyMod;
import fr.niferx.lucky.entity.LuckyEntity;
import fr.niferx.lucky.entity.LuckyPupEntity;
import fr.niferx.lucky.entity.SqueakyBallEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, LuckyMod.MOD_ID);

    public static final RegistryObject<EntityType<LuckyEntity>> LUCKY = ENTITIES.register("lucky",
            () -> EntityType.Builder.of(LuckyEntity::new, MobCategory.MONSTER)
                    .sized(0.95F, 1.2F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build(LuckyMod.MOD_ID + ":lucky"));

    public static final RegistryObject<EntityType<LuckyPupEntity>> LUCKY_PUP = ENTITIES.register("lucky_pup",
            () -> EntityType.Builder.of(LuckyPupEntity::new, MobCategory.MONSTER)
                    .sized(0.55F, 0.6F)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build(LuckyMod.MOD_ID + ":lucky_pup"));

    public static final RegistryObject<EntityType<SqueakyBallEntity>> SQUEAKY_BALL = ENTITIES.register("squeaky_ball",
            () -> EntityType.Builder.<SqueakyBallEntity>of(SqueakyBallEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(6)
                    .updateInterval(2)
                    .build(LuckyMod.MOD_ID + ":squeaky_ball"));

    public static void onAttributeCreation(EntityAttributeCreationEvent event) {
        event.put(LUCKY.get(), LuckyEntity.createAttributes().build());
        event.put(LUCKY_PUP.get(), LuckyPupEntity.createAttributes().build());
    }

    private ModEntities() {
    }
}
