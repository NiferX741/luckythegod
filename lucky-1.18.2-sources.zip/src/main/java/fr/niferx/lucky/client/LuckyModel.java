package fr.niferx.lucky.client;

import fr.niferx.lucky.LuckyMod;
import fr.niferx.lucky.entity.LuckyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;

/**
 * Blocky white miniature spitz. Proportions are tuned in tools/preview_model.py.
 */
public class LuckyModel<T extends LivingEntity> extends EntityModel<T> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath(LuckyMod.MOD_ID, "lucky"), "main");

    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tongue;
    private final ModelPart tail;
    private final ModelPart earL;
    private final ModelPart earR;
    private final ModelPart earLIn;
    private final ModelPart earRIn;
    private final ModelPart eyeL;
    private final ModelPart eyeR;
    private final ModelPart browL;
    private final ModelPart browR;
    private final ModelPart tag;
    private final ModelPart legFL;
    private final ModelPart legFR;
    private final ModelPart legBL;
    private final ModelPart legBR;

    public LuckyModel(ModelPart root) {
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.tongue = this.head.getChild("tongue");
        this.tail = this.body.getChild("tail");
        this.earL = this.head.getChild("ear_l");
        this.earR = this.head.getChild("ear_r");
        this.earLIn = this.head.getChild("ear_l_in");
        this.earRIn = this.head.getChild("ear_r_in");
        this.eyeL = this.head.getChild("eye_l");
        this.eyeR = this.head.getChild("eye_r");
        this.browL = this.head.getChild("brow_l");
        this.browR = this.head.getChild("brow_r");
        this.tag = this.body.getChild("collar").getChild("tag");
        this.legFL = this.body.getChild("leg_fl");
        this.legFR = this.body.getChild("leg_fr");
        this.legBL = this.body.getChild("leg_bl");
        this.legBR = this.body.getChild("leg_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-6.0F, -5.6F, -5.5F, 12.0F, 10.6F, 11.0F)
                        .texOffs(0, 24).addBox(-7.0F, -4.6F, -4.2F, 14.0F, 8.4F, 8.6F),
                PartPose.offset(0.0F, 16.4F, 0.0F));

        body.addOrReplaceChild("ruff", CubeListBuilder.create()
                        .texOffs(48, 16).addBox(-6.6F, -3.6F, -3.4F, 13.2F, 7.2F, 6.6F),
                PartPose.offsetAndRotation(0.0F, -3.6F, -4.8F, 0.35F, 0.0F, 0.0F));

        PartDefinition head = body.addOrReplaceChild("head", CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-4.0F, -5.2F, -3.8F, 8.0F, 6.0F, 6.4F),
                PartPose.offsetAndRotation(0.0F, -7.4F, -3.2F, 0.05F, 0.0F, 0.0F));

        head.addOrReplaceChild("cheek_l", CubeListBuilder.create()
                        .texOffs(80, 0).addBox(0.0F, -1.8F, -1.8F, 2.6F, 3.6F, 3.6F),
                PartPose.offsetAndRotation(3.3F, -2.0F, -1.4F, 0.0F, 0.15F, 0.0F));
        head.addOrReplaceChild("cheek_r", CubeListBuilder.create()
                        .texOffs(80, 0).addBox(-2.6F, -1.8F, -1.8F, 2.6F, 3.6F, 3.6F),
                PartPose.offsetAndRotation(-3.3F, -2.0F, -1.4F, 0.0F, -0.15F, 0.0F));
        head.addOrReplaceChild("snout", CubeListBuilder.create()
                        .texOffs(96, 0).addBox(-1.45F, -1.2F, -2.3F, 2.9F, 2.15F, 2.4F),
                PartPose.offsetAndRotation(0.0F, -1.05F, -3.6F, 0.2F, 0.0F, 0.0F));
        head.addOrReplaceChild("nose", CubeListBuilder.create()
                        .texOffs(98, 50).addBox(-0.85F, -0.7F, -0.55F, 1.7F, 1.25F, 0.8F),
                PartPose.offsetAndRotation(0.0F, -1.7F, -6.15F, 0.15F, 0.0F, 0.0F));
        head.addOrReplaceChild("tongue", CubeListBuilder.create()
                        .texOffs(60, 50).addBox(-0.55F, 0.0F, -0.9F, 1.1F, 0.4F, 1.15F),
                PartPose.offsetAndRotation(0.0F, 0.15F, -5.15F, 0.95F, 0.0F, 0.0F));

        head.addOrReplaceChild("ear_l", CubeListBuilder.create()
                        .texOffs(108, 0).addBox(-1.15F, -2.6F, -0.7F, 2.3F, 2.8F, 1.5F),
                PartPose.offsetAndRotation(2.35F, -4.7F, -0.4F, -0.15F, -0.2F, 0.42F));
        head.addOrReplaceChild("ear_r", CubeListBuilder.create()
                        .texOffs(108, 0).addBox(-1.15F, -2.6F, -0.7F, 2.3F, 2.8F, 1.5F),
                PartPose.offsetAndRotation(-2.35F, -4.7F, -0.4F, -0.15F, 0.2F, -0.42F));
        head.addOrReplaceChild("ear_l_in", CubeListBuilder.create()
                        .texOffs(60, 50).addBox(-0.75F, -1.9F, -0.3F, 1.5F, 1.9F, 0.4F),
                PartPose.offsetAndRotation(2.35F, -4.55F, -0.95F, -0.15F, -0.2F, 0.42F));
        head.addOrReplaceChild("ear_r_in", CubeListBuilder.create()
                        .texOffs(60, 50).addBox(-0.75F, -1.9F, -0.3F, 1.5F, 1.9F, 0.4F),
                PartPose.offsetAndRotation(-2.35F, -4.55F, -0.95F, -0.15F, 0.2F, -0.42F));

        head.addOrReplaceChild("eye_l", CubeListBuilder.create()
                        .texOffs(82, 50).addBox(-0.6F, -0.8F, -0.25F, 1.25F, 1.6F, 0.45F),
                PartPose.offset(1.75F, -3.05F, -4.15F));
        head.addOrReplaceChild("eye_r", CubeListBuilder.create()
                        .texOffs(82, 50).addBox(-0.65F, -0.8F, -0.25F, 1.25F, 1.6F, 0.45F),
                PartPose.offset(-1.75F, -3.05F, -4.15F));
        head.addOrReplaceChild("brow_l", CubeListBuilder.create()
                        .texOffs(112, 50).addBox(-0.95F, -0.28F, -0.25F, 1.8F, 0.5F, 0.35F),
                PartPose.offsetAndRotation(1.85F, -4.15F, -3.65F, 0.0F, 0.0F, 0.55F));
        head.addOrReplaceChild("brow_r", CubeListBuilder.create()
                        .texOffs(112, 50).addBox(-0.85F, -0.28F, -0.25F, 1.8F, 0.5F, 0.35F),
                PartPose.offsetAndRotation(-1.85F, -4.15F, -3.65F, 0.0F, 0.0F, -0.55F));

        PartDefinition collar = body.addOrReplaceChild("collar", CubeListBuilder.create()
                        .texOffs(0, 50).addBox(-4.4F, -1.15F, -2.2F, 8.8F, 2.3F, 4.4F),
                PartPose.offsetAndRotation(0.0F, 0.4F, -4.6F, 0.55F, 0.0F, 0.0F));
        collar.addOrReplaceChild("tag", CubeListBuilder.create()
                        .texOffs(42, 50).addBox(-0.75F, 0.0F, -0.28F, 1.5F, 2.1F, 0.55F),
                PartPose.offsetAndRotation(0.0F, 1.2F, -1.9F, 0.35F, 0.0F, 0.0F));

        PartDefinition tail = body.addOrReplaceChild("tail", CubeListBuilder.create()
                        .texOffs(48, 32).addBox(-1.25F, -3.1F, -1.15F, 2.5F, 3.3F, 2.5F),
                PartPose.offsetAndRotation(0.0F, -4.0F, 3.4F, 0.15F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tail2", CubeListBuilder.create()
                        .texOffs(60, 32).addBox(-2.0F, -2.15F, -1.8F, 4.0F, 3.7F, 3.5F),
                PartPose.offsetAndRotation(0.0F, -3.3F, -1.5F, -0.15F, 0.0F, 0.0F));
        tail.addOrReplaceChild("tail3", CubeListBuilder.create()
                        .texOffs(78, 32).addBox(-2.55F, -1.9F, -2.1F, 5.1F, 3.7F, 4.0F),
                PartPose.offsetAndRotation(0.0F, -2.5F, -4.2F, -0.25F, 0.0F, 0.0F));

        body.addOrReplaceChild("leg_fl", CubeListBuilder.create()
                        .texOffs(100, 32).addBox(-1.05F, 0.0F, -1.05F, 2.1F, 3.4F, 2.1F),
                PartPose.offset(2.7F, 4.3F, -2.4F));
        body.addOrReplaceChild("leg_fr", CubeListBuilder.create()
                        .texOffs(100, 32).addBox(-1.05F, 0.0F, -1.05F, 2.1F, 3.4F, 2.1F),
                PartPose.offset(-2.7F, 4.3F, -2.4F));
        body.addOrReplaceChild("leg_bl", CubeListBuilder.create()
                        .texOffs(100, 32).addBox(-1.05F, 0.0F, -1.05F, 2.1F, 3.4F, 2.1F),
                PartPose.offset(2.8F, 4.3F, 2.8F));
        body.addOrReplaceChild("leg_br", CubeListBuilder.create()
                        .texOffs(100, 32).addBox(-1.05F, 0.0F, -1.05F, 2.1F, 3.4F, 2.1F),
                PartPose.offset(-2.8F, 4.3F, 2.8F));

        return LayerDefinition.create(mesh, 128, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        int mode = 0;
        int phase = 0;
        if (entity instanceof LuckyEntity lucky) {
            mode = lucky.getAttackMode();
            phase = lucky.getPhase();
        }
        boolean mad = phase >= 1;

        this.body.xRot = 0.0F;
        this.body.yRot = 0.0F;
        this.body.zRot = 0.0F;
        this.body.y = 16.4F + Mth.sin(ageInTicks * 0.18F) * 0.12F;

        float swing = Mth.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.legFL.xRot = swing;
        this.legBR.xRot = swing;
        this.legFR.xRot = -swing;
        this.legBL.xRot = -swing;

        this.head.xRot = 0.05F + headPitch * ((float) Math.PI / 180.0F);
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180.0F);
        this.head.zRot = 0.0F;

        float pin = mad ? 0.45F : 0.0F;
        float twitch = Mth.sin(ageInTicks * 0.13F) * 0.04F;
        this.earL.xRot = -0.15F - pin + twitch;
        this.earR.xRot = -0.15F - pin + twitch;
        this.earL.yRot = -0.2F;
        this.earR.yRot = 0.2F;
        this.earL.zRot = 0.42F + pin;
        this.earR.zRot = -0.42F - pin;
        this.earLIn.xRot = this.earL.xRot;
        this.earRIn.xRot = this.earR.xRot;
        this.earLIn.yRot = this.earL.yRot;
        this.earRIn.yRot = this.earR.yRot;
        this.earLIn.zRot = this.earL.zRot;
        this.earRIn.zRot = this.earR.zRot;

        this.browL.visible = mad;
        this.browR.visible = mad;

        float wagSpeed = mad ? 0.45F : 0.25F;
        float wag = mad ? 0.42F : 0.28F;
        if (mode == LuckyEntity.MODE_ZOOMIES) {
            wagSpeed = 0.85F;
            wag = 0.6F;
            this.body.zRot = Mth.sin(ageInTicks * 1.3F) * 0.08F;
        }
        this.tail.xRot = 0.15F;
        this.tail.yRot = Mth.cos(ageInTicks * wagSpeed) * wag;
        this.tail.zRot = 0.0F;

        this.tongue.xRot = 0.95F;
        this.tongue.z = -5.15F;
        this.tag.zRot = Mth.sin(ageInTicks * 0.2F) * 0.08F;

        if (mode == LuckyEntity.MODE_BARK) {
            this.head.xRot += -0.55F + Mth.sin(ageInTicks) * 0.15F;
            this.tongue.xRot = 1.2F;
            this.tongue.z = -5.7F;
        } else if (mode == LuckyEntity.MODE_LUNGE) {
            this.body.xRot = 0.55F;
            this.head.xRot += 0.3F;
        } else if (mode == LuckyEntity.MODE_SPIN) {
            this.body.xRot = 0.15F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.body.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
