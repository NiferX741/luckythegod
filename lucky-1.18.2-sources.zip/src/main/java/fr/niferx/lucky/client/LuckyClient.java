package fr.niferx.lucky.client;

import fr.niferx.lucky.LuckyMod;
import fr.niferx.lucky.registry.ModEntities;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = LuckyMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class LuckyClient {
    private LuckyClient() {
    }

    @SubscribeEvent
    public static void onLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(LuckyModel.LAYER, LuckyModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void onRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.LUCKY.get(), context -> new LuckyRenderer<>(context, 1.0F, 0.5F));
        event.registerEntityRenderer(ModEntities.LUCKY_PUP.get(), context -> new LuckyRenderer<>(context, 0.55F, 0.25F));
        event.registerEntityRenderer(ModEntities.SQUEAKY_BALL.get(), context -> new ThrownItemRenderer<>(context, 1.35F, false));
    }
}
