package fr.niferx.lucky.item;

import fr.niferx.lucky.entity.LuckyEntity;
import fr.niferx.lucky.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

public class LuckyWhistleItem extends Item {
    public LuckyWhistleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }

        if (level.getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) {
            tell(player, "item.lucky.whistle.peaceful");
            return InteractionResultHolder.fail(stack);
        }

        if (!level.getEntitiesOfClass(LuckyEntity.class, player.getBoundingBox().inflate(64.0D)).isEmpty()) {
            tell(player, "item.lucky.whistle.already");
            player.getCooldowns().addCooldown(this, 20);
            return InteractionResultHolder.fail(stack);
        }

        Vec3 look = player.getLookAngle();
        double x = player.getX() + look.x * 2.4D;
        double y = player.getY();
        double z = player.getZ() + look.z * 2.4D;
        BlockPos pos = new BlockPos(x, y, z);
        if (level.getBlockState(pos).getMaterial().blocksMotion()
                || level.getBlockState(pos.above()).getMaterial().blocksMotion()) {
            x = player.getX();
            y = player.getY();
            z = player.getZ();
            pos = player.blockPosition();
        }

        if (!(level instanceof ServerLevel server)) {
            return InteractionResultHolder.fail(stack);
        }

        LuckyEntity lucky = ModEntities.LUCKY.get().create(server);
        if (lucky == null) {
            return InteractionResultHolder.fail(stack);
        }

        lucky.moveTo(x, y, z, player.getYRot() + 180.0F, 0.0F);
        lucky.finalizeSpawn(server, server.getCurrentDifficultyAt(pos), MobSpawnType.MOB_SUMMONED, null, null);
        server.addFreshEntity(lucky);
        lucky.setTarget(player);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.NOTE_BLOCK_FLUTE, SoundSource.PLAYERS, 1.0F, 1.7F);
        lucky.playSound(SoundEvents.WOLF_AMBIENT, 1.4F, 1.35F);

        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        player.getCooldowns().addCooldown(this, 40);
        tell(player, "item.lucky.whistle.summon");
        return InteractionResultHolder.consume(stack);
    }

    private static void tell(Player player, String key) {
        player.displayClientMessage(new TranslatableComponent(key), true);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(new TranslatableComponent("item.lucky.whistle.tooltip").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
