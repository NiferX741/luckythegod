package fr.niferx.lucky.entity;

import fr.niferx.lucky.config.LuckyConfig;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;
import java.util.EnumSet;
import java.util.List;

public class LuckyEntity extends Monster {
    public static final int MODE_IDLE = 0;
    public static final int MODE_BARK = 1;
    public static final int MODE_LUNGE = 2;
    public static final int MODE_SPIN = 3;
    public static final int MODE_ZOOMIES = 4;
    public static final int MODE_THROW = 5;

    private static final EntityDataAccessor<Integer> DATA_MODE =
            SynchedEntityData.defineId(LuckyEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(LuckyEntity.class, EntityDataSerializers.INT);

    private static final Component NAME = new TranslatableComponent("entity.lucky.lucky");
    private static final Component NAME_ENRAGED = new TranslatableComponent("entity.lucky.lucky.enraged");
    private static final Component NAME_ZOOMIES = new TranslatableComponent("entity.lucky.lucky.zoomies");

    private final ServerBossEvent bossEvent =
            new ServerBossEvent(NAME, BossEvent.BossBarColor.WHITE, BossEvent.BossBarOverlay.PROGRESS);

    private int attackTicks;
    private int cooldown = 30;
    private boolean barkReleased;
    private boolean lungeHit;
    private boolean enraged;
    private boolean finalPhase;
    @Nullable
    private Vec3 specialMotion;

    @SuppressWarnings("deprecation")
    public LuckyEntity(EntityType<? extends LuckyEntity> type, Level level) {
        super(type, level);
        this.xpReward = 50;
        this.setPersistenceRequired();
        // The field is the 1.18 way to let him hop onto a full block.
        this.maxUpStep = 1.05F;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, LuckyConfig.MAX_HEALTH.get())
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, LuckyConfig.ATTACK_DAMAGE.get())
                .add(Attributes.ARMOR, LuckyConfig.ARMOR.get())
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.6D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ChaseGoal(this));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 12.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this).setAlertOthers(LuckyPupEntity.class));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_MODE, MODE_IDLE);
        this.entityData.define(DATA_PHASE, 0);
    }

    public int getAttackMode() {
        return this.entityData.get(DATA_MODE);
    }

    public int getPhase() {
        return this.entityData.get(DATA_PHASE);
    }

    public boolean isSpecialMoving() {
        int mode = this.getAttackMode();
        return mode == MODE_BARK || mode == MODE_LUNGE || mode == MODE_SPIN || mode == MODE_ZOOMIES || mode == MODE_THROW;
    }

    private void setAttackMode(int mode) {
        this.entityData.set(DATA_MODE, mode);
    }

    private void setPhase(int phase) {
        this.entityData.set(DATA_PHASE, phase);
    }

    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag tag) {
        spawnData = super.finalizeSpawn(level, difficulty, reason, spawnData, tag);
        float healthScale = switch (level.getDifficulty()) {
            case EASY -> 0.8F;
            case HARD -> 1.25F;
            default -> 1.0F;
        };
        float damageScale = switch (level.getDifficulty()) {
            case EASY -> 0.85F;
            case HARD -> 1.15F;
            default -> 1.0F;
        };
        AttributeInstance health = this.getAttribute(Attributes.MAX_HEALTH);
        AttributeInstance damage = this.getAttribute(Attributes.ATTACK_DAMAGE);
        if (health != null) {
            health.setBaseValue(LuckyConfig.MAX_HEALTH.get() * healthScale);
            this.setHealth(this.getMaxHealth());
        }
        if (damage != null) {
            damage.setBaseValue(LuckyConfig.ATTACK_DAMAGE.get() * damageScale);
        }
        this.setPersistenceRequired();
        return spawnData;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level.isClientSide && this.tickCount % 4 == 0) {
            int mode = this.getAttackMode();
            if (mode == MODE_SPIN || mode == MODE_ZOOMIES || this.getPhase() >= 1) {
                this.level.addParticle(ParticleTypes.SNOWFLAKE,
                        this.getX() + (this.random.nextDouble() - 0.5D) * 0.8D,
                        this.getY() + 0.4D,
                        this.getZ() + (this.random.nextDouble() - 0.5D) * 0.8D,
                        0.0D, 0.02D, 0.0D);
            }
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.updateBossBar();
        this.updatePhases();
        this.tickAttacks();
    }

    private void updateBossBar() {
        float ratio = this.getMaxHealth() <= 0.0F ? 0.0F : this.getHealth() / this.getMaxHealth();
        this.bossEvent.setProgress(Mth.clamp(ratio, 0.0F, 1.0F));
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getCustomName());
            return;
        }
        int phase = this.getPhase();
        if (phase >= 2) {
            this.bossEvent.setName(NAME_ZOOMIES);
            this.bossEvent.setColor(BossEvent.BossBarColor.RED);
        } else if (phase >= 1) {
            this.bossEvent.setName(NAME_ENRAGED);
            this.bossEvent.setColor(BossEvent.BossBarColor.PINK);
        } else {
            this.bossEvent.setName(NAME);
            this.bossEvent.setColor(BossEvent.BossBarColor.WHITE);
        }
    }

    private void updatePhases() {
        float ratio = this.getMaxHealth() <= 0.0F ? 1.0F : this.getHealth() / this.getMaxHealth();
        if (!this.enraged && ratio <= 0.5F && this.isAlive()) {
            this.triggerEnrage();
        }
        if (!this.finalPhase && ratio <= 0.25F && this.isAlive()) {
            this.triggerFinal();
        }
    }

    private void triggerEnrage() {
        this.enraged = true;
        this.setPhase(Math.max(this.getPhase(), 1));
        AttributeInstance damage = this.getAttribute(Attributes.ATTACK_DAMAGE);
        AttributeInstance speed = this.getAttribute(Attributes.MOVEMENT_SPEED);
        if (damage != null) {
            damage.setBaseValue(damage.getBaseValue() * 1.25D);
        }
        if (speed != null) {
            speed.setBaseValue(0.38D);
        }
        this.playSound(SoundEvents.WOLF_GROWL, 1.6F, 0.75F);
        this.burst(ParticleTypes.CLOUD, 24);
        this.summonPups(LuckyConfig.PUP_COUNT.get());
        this.announce(new TranslatableComponent("message.lucky.enrage"));
        this.beginBark();
    }

    private void triggerFinal() {
        this.finalPhase = true;
        this.enraged = true;
        this.setPhase(2);
        this.playSound(SoundEvents.WOLF_GROWL, 1.8F, 1.15F);
        this.burst(ParticleTypes.SNOWFLAKE, 30);
        int extra = Math.max(1, LuckyConfig.PUP_COUNT.get() - 1);
        this.summonPups(extra);
        this.announce(new TranslatableComponent("message.lucky.final"));
        this.beginZoomies();
    }

    private void tickAttacks() {
        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            if (this.getAttackMode() != MODE_IDLE) {
                this.setAttackMode(MODE_IDLE);
            }
            return;
        }

        if (this.attackTicks > 0) {
            this.attackTicks--;
            this.tickActiveAttack(target);
            if (this.attackTicks == 0) {
                this.setAttackMode(MODE_IDLE);
                Vec3 motion = this.getDeltaMovement();
                this.setDeltaMovement(motion.x * 0.25D, motion.y, motion.z * 0.25D);
            }
            return;
        }

        if (this.cooldown > 0) {
            this.cooldown--;
            return;
        }
        this.pickAttack(target);
    }

    private void tickActiveAttack(LivingEntity target) {
        int mode = this.getAttackMode();
        switch (mode) {
            case MODE_BARK -> this.tickBark(target);
            case MODE_LUNGE -> this.tickLunge(target);
            case MODE_SPIN -> this.tickSpin(target);
            case MODE_ZOOMIES -> this.tickZoomies(target);
            case MODE_THROW -> this.face(target);
            default -> {
            }
        }
    }

    private void pickAttack(LivingEntity target) {
        double distance = this.distanceTo(target);
        boolean mad = this.getPhase() >= 1;
        int roll = this.random.nextInt(10);
        if (distance < 6.5D && roll < (mad ? 3 : 2)) {
            this.beginBark();
        } else if (distance > 3.0D && distance < 14.0D && roll < 6) {
            this.beginLunge(target);
        } else if (distance < 5.5D && (mad ? roll < 8 : roll == 6)) {
            this.beginSpin();
        } else if (mad && roll >= 8) {
            this.beginZoomies();
        } else if (distance > 4.0D) {
            this.beginThrow(target);
        } else {
            this.beginBark();
        }
    }

    private void beginBark() {
        this.setAttackMode(MODE_BARK);
        this.attackTicks = 16;
        this.barkReleased = false;
        this.cooldown = this.getPhase() >= 1 ? 36 : 55;
        this.getNavigation().stop();
        this.playSound(SoundEvents.WOLF_AMBIENT, 1.3F, 1.5F);
    }

    private void tickBark(LivingEntity target) {
        this.face(target);
        this.getNavigation().stop();
        if (!this.barkReleased && this.attackTicks == 8) {
            this.barkReleased = true;
            this.shockwave();
        }
    }

    private void shockwave() {
        boolean mad = this.getPhase() >= 1;
        double radius = mad ? 7.0D : 5.5D;
        float baseDamage = mad ? 7.0F : 5.0F;
        this.playSound(SoundEvents.WOLF_GROWL, 1.8F, mad ? 0.8F : 1.25F);
        if (this.level instanceof ServerLevel server) {
            int points = 20;
            for (int i = 0; i < points; i++) {
                double angle = (Math.PI * 2.0D * i) / points;
                server.sendParticles(ParticleTypes.CLOUD,
                        this.getX() + Math.cos(angle) * 1.4D,
                        this.getY() + 0.45D,
                        this.getZ() + Math.sin(angle) * 1.4D,
                        1, 0.0D, 0.0D, 0.0D, 0.0D);
            }
        }
        for (LivingEntity living : this.victims(radius)) {
            if (!this.hasLineOfSight(living)) {
                continue;
            }
            double distance = this.distanceTo(living);
            float damage = baseDamage * (float) (1.0D - distance / (radius + 0.5D));
            living.hurt(DamageSource.mobAttack(this), Math.max(2.0F, damage));
            living.knockback(mad ? 1.25D : 0.85D, this.getX() - living.getX(), this.getZ() - living.getZ());
            Vec3 motion = living.getDeltaMovement().add(0.0D, 0.22D, 0.0D);
            living.setDeltaMovement(motion);
            living.hurtMarked = true;
            living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, mad ? 50 : 35, 1));
        }
    }

    private void beginLunge(LivingEntity target) {
        Vec3 dir = this.horizontalToward(target);
        if (dir == null) {
            this.beginBark();
            return;
        }
        this.setAttackMode(MODE_LUNGE);
        this.attackTicks = 12;
        this.lungeHit = false;
        this.cooldown = this.getPhase() >= 1 ? 24 : 36;
        this.getNavigation().stop();
        this.specialMotion = new Vec3(dir.x * 1.05D, 0.46D, dir.z * 1.05D);
        this.faceDirection(dir);
        this.playSound(SoundEvents.WOLF_GROWL, 1.0F, 1.45F);
    }

    private void tickLunge(LivingEntity target) {
        if (this.lungeHit) {
            return;
        }
        AABB box = this.getBoundingBox().inflate(0.7D);
        for (LivingEntity living : this.level.getEntitiesOfClass(LivingEntity.class, box, this::isVictim)) {
            float damage = (float) this.getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.35F;
            if (living.hurt(DamageSource.mobAttack(this), damage)) {
                living.knockback(0.7D, this.getX() - living.getX(), this.getZ() - living.getZ());
                this.playSound(SoundEvents.FOX_BITE, 0.8F, 1.2F);
                this.lungeHit = true;
                break;
            }
        }
    }

    private void beginSpin() {
        this.setAttackMode(MODE_SPIN);
        this.attackTicks = this.getPhase() >= 1 ? 46 : 34;
        this.cooldown = this.getPhase() >= 1 ? 50 : 75;
        this.getNavigation().stop();
        this.playSound(SoundEvents.WOLF_AMBIENT, 1.2F, 1.6F);
    }

    private void tickSpin(LivingEntity target) {
        this.setYRot(this.getYRot() + (this.getPhase() >= 1 ? 46.0F : 34.0F));
        this.yBodyRot = this.getYRot();
        this.yHeadRot = this.getYRot();
        Vec3 dir = this.horizontalToward(target);
        Vec3 current = this.getDeltaMovement();
        if (dir != null) {
            this.specialMotion = new Vec3(dir.x * 0.18D, current.y, dir.z * 0.18D);
        }
        if (this.attackTicks % 8 == 0) {
            float damage = this.getPhase() >= 1 ? 5.0F : 3.5F;
            for (LivingEntity living : this.victims(2.6D)) {
                living.hurt(DamageSource.mobAttack(this), damage);
                living.knockback(0.45D, this.getX() - living.getX(), this.getZ() - living.getZ());
                if (this.getPhase() >= 2) {
                    living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 15, 0, false, false));
                }
            }
            this.burst(ParticleTypes.CLOUD, 10);
        }
    }

    private void beginZoomies() {
        this.setAttackMode(MODE_ZOOMIES);
        this.attackTicks = 64;
        this.cooldown = 70;
        this.getNavigation().stop();
        this.playSound(SoundEvents.WOLF_AMBIENT, 1.4F, 1.7F);
    }

    private void tickZoomies(LivingEntity target) {
        Vec3 to = this.horizontalToward(target);
        if (to == null) {
            to = new Vec3(1.0D, 0.0D, 0.0D);
        }
        Vec3 side = new Vec3(-to.z, 0.0D, to.x);
        double flip = ((this.tickCount / 12) % 2 == 0) ? 1.0D : -1.0D;
        double forward = this.distanceTo(target) > 2.8D ? 0.55D : 0.12D;
        Vec3 current = this.getDeltaMovement();
        Vec3 velocity = to.scale(forward).add(side.scale(0.48D * flip));
        this.specialMotion = new Vec3(velocity.x, Math.max(current.y, this.onGround ? 0.12D : current.y), velocity.z);
        this.faceDirection(velocity);
        if (this.distanceToSqr(target) < 3.4D && this.attackTicks % 8 == 0) {
            this.doHurtTarget(target);
        }
        if (this.tickCount % 2 == 0) {
            this.burst(ParticleTypes.CLOUD, 1);
        }
    }

    private void beginThrow(LivingEntity target) {
        this.setAttackMode(MODE_THROW);
        this.attackTicks = 8;
        this.cooldown = this.getPhase() >= 1 ? 30 : 45;
        this.getNavigation().stop();
        this.face(target);
        int count = this.getPhase() >= 1 ? 3 : 1;
        float inaccuracy = this.getPhase() >= 1 ? 8.0F : 4.0F;
        float damage = this.getPhase() >= 2 ? 8.0F : 6.0F;
        for (int i = 0; i < count; i++) {
            SqueakyBallEntity ball = new SqueakyBallEntity(this.level, this);
            ball.setPos(this.getX(), this.getEyeY() - 0.1D, this.getZ());
            double dx = target.getX() - this.getX();
            double dy = target.getEyeY() - ball.getY();
            double dz = target.getZ() - this.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            ball.shoot(dx, dy + horizontal * 0.12D, dz, 1.15F, inaccuracy);
            ball.setDamage(damage);
            this.level.addFreshEntity(ball);
        }
        this.playSound(SoundEvents.SLIME_SQUISH_SMALL, 1.0F, 1.8F);
    }

    private void summonPups(int count) {
        if (count <= 0 || !(this.level instanceof ServerLevel server)) {
            return;
        }
        for (int i = 0; i < count; i++) {
            LuckyPupEntity pup = fr.niferx.lucky.registry.ModEntities.LUCKY_PUP.get().create(server);
            if (pup == null) {
                continue;
            }
            double angle = (Math.PI * 2.0D * i) / count + this.random.nextDouble();
            double x = this.getX() + Math.cos(angle) * 1.3D;
            double z = this.getZ() + Math.sin(angle) * 1.3D;
            pup.moveTo(x, this.getY(), z, this.random.nextFloat() * 360.0F, 0.0F);
            pup.summonedBy(this, 20 * 45);
            if (this.getTarget() != null) {
                pup.setTarget(this.getTarget());
            }
            server.addFreshEntity(pup);
            server.sendParticles(ParticleTypes.CLOUD, x, this.getY() + 0.3D, z, 8, 0.2D, 0.15D, 0.2D, 0.02D);
        }
    }

    private List<LivingEntity> victims(double radius) {
        return this.level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(radius), this::isVictim);
    }

    private boolean isVictim(LivingEntity living) {
        if (living == this || !living.isAlive() || living.isSpectator()) {
            return false;
        }
        if (living instanceof LuckyEntity || living instanceof LuckyPupEntity) {
            return false;
        }
        if (living instanceof Player player) {
            return !player.isCreative() && !player.isSpectator();
        }
        return living instanceof net.minecraft.world.entity.monster.Enemy;
    }

    @Nullable
    private Vec3 horizontalToward(LivingEntity target) {
        Vec3 dir = new Vec3(target.getX() - this.getX(), 0.0D, target.getZ() - this.getZ());
        if (dir.lengthSqr() < 1.0E-4D) {
            return null;
        }
        return dir.normalize();
    }

    private void face(LivingEntity target) {
        Vec3 dir = this.horizontalToward(target);
        if (dir != null) {
            this.faceDirection(dir);
        }
        this.getLookControl().setLookAt(target, 40.0F, 40.0F);
    }

    private void faceDirection(Vec3 dir) {
        float yaw = (float) (Mth.atan2(dir.z, dir.x) * (180.0D / Math.PI)) - 90.0F;
        this.setYRot(yaw);
        this.yBodyRot = yaw;
        this.yHeadRot = yaw;
    }

    private void burst(ParticleOptions particle, int count) {
        if (this.level instanceof ServerLevel server) {
            server.sendParticles(particle, this.getX(), this.getY() + this.getBbHeight() * 0.5D, this.getZ(),
                    count, 0.35D, 0.25D, 0.35D, 0.02D);
        }
    }

    private void announce(Component message) {
        if (!(this.level instanceof ServerLevel server)) {
            return;
        }
        for (ServerPlayer player : server.players()) {
            if (player.distanceToSqr(this) < 48.0D * 48.0D) {
                player.displayClientMessage(message, false);
            }
        }
    }

    @Override
    public void travel(Vec3 input) {
        int mode = this.getAttackMode();
        if (this.specialMotion != null) {
            this.setDeltaMovement(this.specialMotion);
            this.specialMotion = null;
            this.setSpeed(0.0F);
            super.travel(Vec3.ZERO);
            return;
        }
        if (mode == MODE_BARK || mode == MODE_THROW || mode == MODE_LUNGE) {
            this.setSpeed(0.0F);
            super.travel(Vec3.ZERO);
            return;
        }
        super.travel(input);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        if (target instanceof LuckyEntity || target instanceof LuckyPupEntity) {
            return false;
        }
        boolean hurt = super.doHurtTarget(target);
        if (hurt) {
            this.playSound(SoundEvents.FOX_BITE, 0.7F, 1.25F);
        }
        return hurt;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (source == DamageSource.FALL) {
            return false;
        }
        if (this.getAttackMode() == MODE_SPIN && !source.isBypassArmor()) {
            amount *= 0.65F;
        }
        boolean hurt = super.hurt(source, amount);
        if (hurt) {
            this.invulnerableTime = 10;
            if (this.getAttackMode() == MODE_IDLE) {
                this.cooldown = Math.min(this.cooldown, 8);
            }
        }
        return hurt;
    }

    @Override
    public boolean causeFallDamage(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    protected boolean isSunBurnTick() {
        return false;
    }

    @Override
    public void checkDespawn() {
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return false;
    }

    @Override
    public void die(DamageSource source) {
        if (this.level instanceof ServerLevel server) {
            for (LuckyPupEntity pup : server.getEntitiesOfClass(LuckyPupEntity.class, this.getBoundingBox().inflate(48.0D))) {
                if (this.getUUID().equals(pup.getOwnerId())) {
                    pup.poof();
                }
            }
            server.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.4D, this.getZ(), 30, 0.4D, 0.3D, 0.4D, 0.04D);
            server.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.6D, this.getZ(), 6, 0.3D, 0.3D, 0.3D, 0.0D);
        }
        super.die(source);
    }

    @Override
    public void remove(RemovalReason reason) {
        this.bossEvent.removeAllPlayers();
        super.remove(reason);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        if (name != null) {
            this.bossEvent.setName(name);
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.getPhase() >= 1 ? SoundEvents.WOLF_GROWL : SoundEvents.WOLF_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WOLF_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WOLF_DEATH;
    }

    @Override
    protected void playStepSound(net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state) {
        this.playSound(SoundEvents.WOLF_STEP, 0.3F, 1.45F);
    }

    @Override
    public float getVoicePitch() {
        return this.getPhase() >= 1 ? 1.05F : 1.35F;
    }

    @Override
    public int getAmbientSoundInterval() {
        return this.getPhase() >= 1 ? 45 : 90;
    }

    @Override
    protected float getStandingEyeHeight(net.minecraft.world.entity.Pose pose, net.minecraft.world.entity.EntityDimensions dimensions) {
        return dimensions.height * 0.78F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Enraged", this.enraged);
        tag.putBoolean("FinalPhase", this.finalPhase);
        tag.putInt("AttackCooldown", this.cooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.enraged = tag.getBoolean("Enraged");
        this.finalPhase = tag.getBoolean("FinalPhase");
        this.cooldown = tag.getInt("AttackCooldown");
        this.setPhase(this.finalPhase ? 2 : this.enraged ? 1 : 0);
        this.setAttackMode(MODE_IDLE);
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getCustomName());
        }
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    /**
     * Walks up to a target and bites. Special attacks take the controls instead.
     */
    static class ChaseGoal extends Goal {
        private final LuckyEntity dog;
        private int biteCooldown;

        ChaseGoal(LuckyEntity dog) {
            this.dog = dog;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = this.dog.getTarget();
            return target != null && target.isAlive() && !this.dog.isSpecialMoving();
        }

        @Override
        public boolean canContinueToUse() {
            return this.canUse();
        }

        @Override
        public void tick() {
            LivingEntity target = this.dog.getTarget();
            if (target == null) {
                return;
            }
            this.dog.getLookControl().setLookAt(target, 30.0F, 30.0F);
            double speed = this.dog.getPhase() >= 1 ? 1.35D : 1.15D;
            this.dog.getNavigation().moveTo(target, speed);
            if (this.biteCooldown > 0) {
                this.biteCooldown--;
            }
            if (this.dog.distanceToSqr(target) < 3.3D && this.biteCooldown == 0) {
                this.dog.doHurtTarget(target);
                this.biteCooldown = this.dog.getPhase() >= 1 ? 10 : 14;
            }
        }

        @Override
        public void stop() {
            this.dog.getNavigation().stop();
        }
    }
}
