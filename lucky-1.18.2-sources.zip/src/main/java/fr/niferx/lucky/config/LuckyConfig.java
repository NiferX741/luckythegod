package fr.niferx.lucky.config;

import net.minecraftforge.common.ForgeConfigSpec;

public final class LuckyConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue MAX_HEALTH;
    public static final ForgeConfigSpec.DoubleValue ATTACK_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue ARMOR;
    public static final ForgeConfigSpec.IntValue PUP_COUNT;

    static {
        ForgeConfigSpec.Builder builder = new ForgeConfigSpec.Builder();
        builder.comment("Lucky, le spitz nain blanc.").push("lucky");
        MAX_HEALTH = builder
                .comment("Points de vie de Lucky. Un coeur = 2 points. 250 = 125 coeurs.")
                .defineInRange("maxHealth", 250.0D, 40.0D, 4000.0D);
        ATTACK_DAMAGE = builder
                .comment("Degats d'une morsure, avant l'armure du joueur.")
                .defineInRange("attackDamage", 7.0D, 1.0D, 40.0D);
        ARMOR = builder
                .comment("Points d'armure de Lucky.")
                .defineInRange("armor", 4.0D, 0.0D, 30.0D);
        PUP_COUNT = builder
                .comment("Boules de poils invoquees quand Lucky passe sous 50% de vie.")
                .defineInRange("pupCount", 3, 0, 8);
        builder.pop();
        SPEC = builder.build();
    }

    private LuckyConfig() {
    }
}
