#!/usr/bin/env python3
"""Generate Lucky's entity, item, and mod-list textures."""

import random
import struct
import zlib
from pathlib import Path

ROOT = Path("/workspace/src/main/resources")


def write_png(path: Path, w: int, h: int, rgba: bytearray) -> None:
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw.extend(rgba[y * w * 4:(y + 1) * w * 4])

    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def fur_pixel(x: int, y: int, rose: float = 0.0):
    n = random.Random(x * 734287 + y * 912763 + 11).randrange(-16, 10)
    r = max(0, min(255, 250 + n))
    g = max(0, min(255, 246 + n - 2))
    b = max(0, min(255, 238 + n - 8))
    if rose:
        r = int(r * (1 - rose) + 255 * rose)
        g = int(g * (1 - rose) + 196 * rose)
        b = int(b * (1 - rose) + 204 * rose)
    return r, g, b, 255


def fill_rect(buf, w, x0, y0, x1, y1, color):
    h = len(buf) // (w * 4)
    x0 = max(0, x0)
    y0 = max(0, y0)
    x1 = min(w, x1)
    y1 = min(h, y1)
    for y in range(y0, y1):
        for x in range(x0, x1):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes(color)


def entity_texture(rose: float = 0.0) -> bytearray:
    w, h = 128, 64
    buf = bytearray(w * h * 4)
    for y in range(h):
        for x in range(w):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes(fur_pixel(x, y, rose))
    # Solid islands for the small feature cubes. Fur cubes do not sample these.
    fill_rect(buf, w, 0, 50, 40, 64, (196, 48, 58, 255))       # collar
    fill_rect(buf, w, 42, 50, 58, 64, (227, 179, 65, 255))      # tag
    fill_rect(buf, w, 60, 50, 80, 64, (242, 168, 184, 255))     # tongue + inner ear
    fill_rect(buf, w, 82, 50, 96, 64, (18, 16, 22, 255))        # eyes
    fill_rect(buf, w, 84, 51, 86, 53, (255, 255, 255, 255))     # catchlight
    fill_rect(buf, w, 98, 50, 110, 64, (28, 24, 30, 255))       # nose
    brow = (120, 64, 72, 255) if rose else (74, 55, 47, 255)
    fill_rect(buf, w, 112, 50, 128, 64, brow)
    return buf


def blit_row(buf, w, y, row, palette):
    for x, ch in enumerate(row):
        color = palette.get(ch)
        if color is None:
            continue
        i = (y * w + x) * 4
        buf[i:i + 4] = bytes(color)


def item_whistle():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "D": (150, 156, 164, 255),
        "S": (214, 220, 226, 255),
        "W": (244, 246, 248, 255),
        "K": (32, 34, 40, 255),
        "R": (196, 48, 58, 255),
        "r": (140, 28, 38, 255),
    }
    rows = [
        "................",
        "......DDDD......",
        ".....DSSSWD.....",
        "....DSWKKSWD.R..",
        "....DSWWWSWD.R..",
        ".....DDDDDD..R..",
        "...........rR...",
        "..........R.....",
        ".........R......",
        "........R.......",
        ".......R........",
        "......RRR.......",
        ".....R..R.......",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_collar():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "R": (196, 48, 58, 255),
        "D": (140, 28, 38, 255),
        "G": (227, 179, 65, 255),
        "g": (168, 122, 36, 255),
        "W": (255, 236, 170, 255),
    }
    rows = [
        "................",
        "................",
        "..DDDDDDDDDDD...",
        ".DRRRRRRRRRRRD..",
        ".DRRRRRRRRRRRD..",
        ".DRRRGGGRRRRRD..",
        "..DRRRGRRRRRD...",
        "....DDDDDDD.....",
        "......gGg.......",
        "......gWg.......",
        "......gGg.......",
        ".......g........",
        "................",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_ball():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "R": (204, 42, 52, 255),
        "D": (150, 24, 34, 255),
        "W": (255, 220, 220, 255),
        "K": (48, 16, 20, 255),
        "L": (255, 170, 170, 255),
    }
    rows = [
        "................",
        "................",
        ".....DDDDD......",
        "....DRRRRRRD....",
        "...DRWWLRRRRD...",
        "...DRRRRRRRRD...",
        "..DRRRRRRRRRRD..",
        "..DRRRKKKRRRRD..",
        "..DRRRRRRRRRRD..",
        "...DRRRRRRRRD...",
        "...DRRRRRRRRD...",
        "....DRRRRRRD....",
        ".....DDDDD......",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_fluff():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "W": (255, 252, 248, 255),
        "C": (236, 228, 216, 255),
        "S": (214, 204, 190, 255),
    }
    rows = [
        "................",
        "................",
        "....WWWW........",
        "...WWCCWWW......",
        "..WWCCCCWWWW....",
        ".WWCCCWWCCCWW...",
        ".WCCCWWWWCCSW...",
        "..WWCCCCCCSWW...",
        "...WWCCCSSWW....",
        "....WWSSWW......",
        ".....WWW........",
        "................",
        "................",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def logo():
    """128x128 face for the mod list."""
    w = h = 128
    buf = bytearray(w * h * 4)
    # soft slate backdrop
    for y in range(h):
        for x in range(w):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes((46, 52, 64, 255))

    def disc(cx, cy, rx, ry, color):
        for y in range(h):
            for x in range(w):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1:
                    i = (y * w + x) * 4
                    buf[i:i + 4] = bytes(color)

    def tri_ear(cx, top, half, height, color):
        for y in range(top, min(h, top + height)):
            t = (y - top) / height
            span = half * t
            for x in range(int(cx - span), int(cx + span) + 1):
                if 0 <= x < w:
                    i = (y * w + x) * 4
                    buf[i:i + 4] = bytes(color)

    disc(64, 74, 46, 42, (247, 244, 238, 255))
    tri_ear(34, 18, 16, 36, (245, 240, 232, 255))
    tri_ear(94, 18, 16, 36, (245, 240, 232, 255))
    tri_ear(34, 24, 8, 22, (242, 168, 184, 255))
    tri_ear(94, 24, 8, 22, (242, 168, 184, 255))
    disc(46, 70, 8, 10, (24, 20, 26, 255))
    disc(82, 70, 8, 10, (24, 20, 26, 255))
    disc(49, 67, 2, 2, (255, 255, 255, 255))
    disc(85, 67, 2, 2, (255, 255, 255, 255))
    disc(64, 86, 7, 5, (32, 26, 30, 255))
    disc(64, 98, 5, 3, (226, 130, 148, 255))
    # collar
    for y in range(108, 118):
        for x in range(28, 100):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes((196, 48, 58, 255))
    disc(64, 120, 5, 6, (227, 179, 65, 255))
    return buf


def main():
    entity = ROOT / "assets/lucky/textures/entity"
    item = ROOT / "assets/lucky/textures/item"
    write_png(entity / "lucky.png", 128, 64, entity_texture(0.0))
    write_png(entity / "lucky_enraged.png", 128, 64, entity_texture(0.14))
    write_png(item / "whistle.png", 16, 16, item_whistle())
    write_png(item / "collar.png", 16, 16, item_collar())
    write_png(item / "squeaky_ball.png", 16, 16, item_ball())
    write_png(item / "fluff.png", 16, 16, item_fluff())
    write_png(ROOT / "logo.png", 128, 128, logo())
    print("textures written")


if __name__ == "__main__":
    main()
