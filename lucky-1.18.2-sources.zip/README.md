# Lucky

Mod Forge **Minecraft 1.18.2** qui ajoute Lucky, un spitz nain blanc, en combat de boss.

Il est petit, rond, et beaucoup trop sûr de lui. La barre de vie porte son nom. Sous 50 % de vie il retrousse les babines, accélère, et appelle des boules de poils. Sous 25 %, il part en zoomies.

## Installer

1. Installe [Forge 1.18.2](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.18.2.html) — le mod est compilé pour **Forge 40.3.12**.
2. Lance le jeu une fois pour créer le dossier `mods`.
3. Copie `build/libs/lucky-1.0.0.jar` dans ce dossier.
4. Java 17, comme le demande Minecraft 1.18.

## Lancer le combat

En survie, fabrique un **sifflet** :

- 2 lingots de fer
- 1 pépite d'or
- 1 os

Utilise-le. Lucky apparaît devant toi et te prend pour un jouet. Le sifflet est consommé. En mode Paisible, il refuse de venir.

En créatif, l'œuf d'apparition `Lucky` est dans l'onglet du même nom, et `/summon lucky:lucky` marche aussi. Un joueur en créatif n'est pas une cible : passe en survie pour le combat.

## Le combat

| Attaque | Ce que ça fait |
| --- | --- |
| Morsure | Au contact, rapide. Plus encore quand il est furieux. |
| Bond | Il se jette et mord plus fort à l'arrivée. |
| Aboiement | Onde qui blesse, repousse et ralentit. |
| Tornade de poils | Il tourne sur lui-même et blesse autour. Les coups portés pendant la tornade sont réduits. |
| Balle qui couine | Projectile qui rebondit. Trois balles d'un coup une fois furieux. |
| Zoomies | Sous 25 % de vie : il file en cercle et mord au passage. |
| Boules de poils | Petits spitz invoqués à 50 %, puis encore à 25 %. Ils disparaissent avec lui, ou au bout de 45 secondes. |

Il ne brûle pas au soleil, ne subit pas les dégâts de chute, et ne disparaît pas si tu t'éloignes. La difficulté du monde change ses points de vie et ses dégâts.

Butin : collier (si tu portes le coup fatal), poils de spitz, balles, et parfois un autre sifflet. Le collier, gardé dans l'inventaire, donne Chance I. Les poils servent à le fabriquer.

Réglages dans `config/lucky-common.toml` (vie, dégâts, armure, nombre de boules de poils). Un redémarrage est nécessaire.

## Compiler

Java 17 :

```bash
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64   # adapte le chemin
./gradlew build
```

Le jar est `build/libs/lucky-1.0.0.jar`.

Pour ouvrir le jeu de développement :

```bash
./gradlew runClient
```

Les textures se régénèrent avec `python3 tools/gen_textures.py`. L'aperçu du modèle (hors jeu) est `python3 tools/preview_model.py`.

Le code du mod est sous licence MIT. Lucky appartient à NiferX.
