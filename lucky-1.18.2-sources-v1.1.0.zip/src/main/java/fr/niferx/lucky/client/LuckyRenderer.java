package fr.niferx.lucky.client;

import fr.niferx.lucky.LuckyMod;
import fr.niferx.lucky.entity.LuckyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Mob;

public class LuckyRenderer<T extends Mob> extends MobRenderer<T, LuckyModel<T>> {
    private static final ResourceLocation CALM = ResourceLocation.fromNamespaceAndPath(LuckyMod.MOD_ID, "textures/entity/lucky.png");
    private static final ResourceLocation ENRAGED = ResourceLocation.fromNamespaceAndPath(LuckyMod.MOD_ID, "textures/entity/lucky_enraged.png");

    private final float modelScale;

    public LuckyRenderer(EntityRendererProvider.Context context, float modelScale, float shadow) {
        super(context, new LuckyModel<>(context.bakeLayer(LuckyModel.LAYER)), shadow);
        this.modelScale = modelScale;
    }

    @Override
    public ResourceLocation getTextureLocation(T entity) {
        if (entity instanceof LuckyEntity lucky && lucky.getPhase() >= 1) {
            return ENRAGED;
        }
        return CALM;
    }

    @Override
    protected void scale(T entity, PoseStack poseStack, float partialTick) {
        float scale = this.modelScale;
        if (entity instanceof LuckyEntity lucky) {
            if (lucky.getPhase() >= 2) {
                scale *= 1.05F;
            }
            if (lucky.getAttackMode() == LuckyEntity.MODE_SPIN) {
                scale *= 1.0F + Mth.sin((entity.tickCount + partialTick) * 0.7F) * 0.05F;
            }
        }
        poseStack.scale(scale, scale, scale);
    }
}
