package fr.niferx.lucky.client;

import fr.niferx.lucky.LuckyMod;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

/**
 * Lucky's hood uses real geometry so the small rounded spitz ears stick out.
 */
public class FluffArmorModel<T extends LivingEntity> extends HumanoidModel<T> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(LuckyMod.MOD_ID, "fluff_armor"), "main");

    private final net.minecraft.client.model.geom.ModelPart muzzle;
    private final net.minecraft.client.model.geom.ModelPart nose;
    private final net.minecraft.client.model.geom.ModelPart leftCheek;
    private final net.minecraft.client.model.geom.ModelPart rightCheek;
    private final net.minecraft.client.model.geom.ModelPart ruff;
    private final net.minecraft.client.model.geom.ModelPart chestPlate;
    private final net.minecraft.client.model.geom.ModelPart waistPlate;
    private final net.minecraft.client.model.geom.ModelPart rightPauldron;
    private final net.minecraft.client.model.geom.ModelPart leftPauldron;
    private final net.minecraft.client.model.geom.ModelPart rightCuff;
    private final net.minecraft.client.model.geom.ModelPart leftCuff;
    private final net.minecraft.client.model.geom.ModelPart rightKnee;
    private final net.minecraft.client.model.geom.ModelPart leftKnee;
    private final net.minecraft.client.model.geom.ModelPart rightBootCuff;
    private final net.minecraft.client.model.geom.ModelPart leftBootCuff;

    public FluffArmorModel(net.minecraft.client.model.geom.ModelPart root) {
        super(root);
        this.muzzle = this.head.getChild("muzzle");
        this.nose = this.head.getChild("nose");
        this.leftCheek = this.head.getChild("left_cheek");
        this.rightCheek = this.head.getChild("right_cheek");
        this.ruff = this.body.getChild("ruff");
        this.chestPlate = this.body.getChild("chest_plate");
        this.waistPlate = this.body.getChild("waist_plate");
        this.rightPauldron = this.rightArm.getChild("pauldron");
        this.leftPauldron = this.leftArm.getChild("pauldron");
        this.rightCuff = this.rightArm.getChild("cuff");
        this.leftCuff = this.leftArm.getChild("cuff");
        this.rightKnee = this.rightLeg.getChild("knee");
        this.leftKnee = this.leftLeg.getChild("knee");
        this.rightBootCuff = this.rightLeg.getChild("boot_cuff");
        this.leftBootCuff = this.leftLeg.getChild("boot_cuff");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = HumanoidModel.createMesh(new CubeDeformation(1.0F), 0.0F);
        PartDefinition head = mesh.getRoot().getChild("head");

        addEar(head, "left_ear", 2.7F, -0.19F);
        addEar(head, "right_ear", -2.7F, 0.19F);

        head.addOrReplaceChild("left_cheek", CubeListBuilder.create()
                        .texOffs(64, 14)
                        .addBox(-0.2F, -2.9F, -2.4F, 2.4F, 5.2F, 4.8F, new CubeDeformation(0.22F)),
                PartPose.offset(3.7F, -3.35F, -0.55F));
        head.addOrReplaceChild("right_cheek", CubeListBuilder.create()
                        .texOffs(64, 14)
                        .addBox(-2.2F, -2.9F, -2.4F, 2.4F, 5.2F, 4.8F, new CubeDeformation(0.22F)),
                PartPose.offset(-3.7F, -3.35F, -0.55F));
        head.addOrReplaceChild("muzzle", CubeListBuilder.create()
                        .texOffs(82, 0)
                        .addBox(-2.8F, -1.6F, -2.35F, 5.6F, 3.4F, 2.6F, new CubeDeformation(0.12F)),
                PartPose.offset(0.0F, -2.15F, -4.1F));
        head.addOrReplaceChild("nose", CubeListBuilder.create()
                        .texOffs(102, 0)
                        .addBox(-1.45F, -0.9F, -0.8F, 2.9F, 1.8F, 1.0F, new CubeDeformation(0.08F)),
                PartPose.offset(0.0F, -2.75F, -6.65F));

        PartDefinition body = mesh.getRoot().getChild("body");
        body.addOrReplaceChild("ruff", CubeListBuilder.create()
                        .texOffs(64, 24)
                        .addBox(-5.3F, -1.8F, -3.0F, 10.6F, 4.5F, 6.0F, new CubeDeformation(0.28F)),
                PartPose.ZERO);
        body.addOrReplaceChild("chest_plate", CubeListBuilder.create()
                        .texOffs(64, 36)
                        .addBox(-4.4F, 2.2F, -3.05F, 8.8F, 6.2F, 1.1F, new CubeDeformation(0.08F)),
                PartPose.ZERO);
        body.addOrReplaceChild("waist_plate", CubeListBuilder.create()
                        .texOffs(86, 36)
                        .addBox(-4.55F, 8.1F, -3.0F, 9.1F, 3.2F, 1.0F, new CubeDeformation(0.08F)),
                PartPose.ZERO);

        addArmDetails(mesh.getRoot().getChild("right_arm"), true);
        addArmDetails(mesh.getRoot().getChild("left_arm"), false);
        addLegDetails(mesh.getRoot().getChild("right_leg"));
        addLegDetails(mesh.getRoot().getChild("left_leg"));

        return LayerDefinition.create(mesh, 128, 64);
    }

    private static void addEar(PartDefinition head, String name, float x, float roll) {
        PartDefinition ear = head.addOrReplaceChild(name, CubeListBuilder.create()
                        .texOffs(64, 0)
                        .addBox(-1.6F, -3.55F, -1.0F, 3.2F, 3.8F, 2.0F, new CubeDeformation(0.12F))
                        .texOffs(64, 8)
                        .addBox(-1.1F, -4.9F, -0.75F, 2.2F, 1.9F, 1.5F, new CubeDeformation(0.08F)),
                PartPose.offsetAndRotation(x, -7.35F, -0.15F, -0.08F, 0.0F, roll));

        ear.addOrReplaceChild("inner", CubeListBuilder.create()
                        .texOffs(76, 0)
                        .addBox(-0.95F, -3.0F, -1.18F, 1.9F, 2.5F, 0.28F),
                PartPose.ZERO);
    }

    private static void addArmDetails(PartDefinition arm, boolean right) {
        float pauldronX = right ? -4.0F : -2.0F;
        arm.addOrReplaceChild("pauldron", CubeListBuilder.create()
                        .texOffs(96, 14)
                        .addBox(pauldronX, -3.15F, -3.0F, 6.0F, 5.0F, 6.0F, new CubeDeformation(0.18F)),
                PartPose.ZERO);

        float cuffX = right ? -3.45F : -1.55F;
        arm.addOrReplaceChild("cuff", CubeListBuilder.create()
                        .texOffs(106, 28)
                        .addBox(cuffX, 6.7F, -2.55F, 5.0F, 4.0F, 5.0F, new CubeDeformation(0.18F)),
                PartPose.ZERO);
    }

    private static void addLegDetails(PartDefinition leg) {
        leg.addOrReplaceChild("knee", CubeListBuilder.create()
                        .texOffs(64, 46)
                        .addBox(-2.7F, 3.7F, -3.35F, 5.4F, 4.4F, 1.8F, new CubeDeformation(0.12F)),
                PartPose.ZERO);
        leg.addOrReplaceChild("boot_cuff", CubeListBuilder.create()
                        .texOffs(78, 46)
                        .addBox(-2.6F, 7.2F, -2.6F, 5.2F, 3.3F, 5.2F, new CubeDeformation(0.12F)),
                PartPose.ZERO);
    }

    public void setCustomVisibility(EquipmentSlot slot) {
        boolean headPiece = slot == EquipmentSlot.HEAD;
        this.muzzle.visible = headPiece;
        this.nose.visible = headPiece;
        this.leftCheek.visible = headPiece;
        this.rightCheek.visible = headPiece;

        boolean chestPiece = slot == EquipmentSlot.CHEST;
        this.ruff.visible = chestPiece;
        this.chestPlate.visible = chestPiece;
        this.waistPlate.visible = chestPiece;
        this.rightPauldron.visible = chestPiece;
        this.leftPauldron.visible = chestPiece;
        this.rightCuff.visible = chestPiece;
        this.leftCuff.visible = chestPiece;

        boolean legsPiece = slot == EquipmentSlot.LEGS;
        this.rightKnee.visible = legsPiece;
        this.leftKnee.visible = legsPiece;

        boolean feetPiece = slot == EquipmentSlot.FEET;
        this.rightBootCuff.visible = feetPiece;
        this.leftBootCuff.visible = feetPiece;
    }
}
