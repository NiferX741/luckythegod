package fr.niferx.lucky;

import net.minecraft.advancements.Advancement;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;

/**
 * The defeat advancement is what unlocks Lucky as a companion.
 */
public final class LuckyProgress {
    public static final ResourceLocation DEFEAT_ID =
            ResourceLocation.fromNamespaceAndPath(LuckyMod.MOD_ID, "defeat_lucky");

    private LuckyProgress() {
    }

    public static boolean hasDefeated(ServerPlayer player) {
        AdvancementProgress progress = progress(player);
        return progress != null && progress.isDone();
    }

    public static void grantDefeat(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        Advancement advancement = server.getAdvancements().getAdvancement(DEFEAT_ID);
        if (advancement == null) {
            return;
        }
        AdvancementProgress progress = player.getAdvancements().getOrStartProgress(advancement);
        if (progress.isDone()) {
            return;
        }
        for (String criterion : progress.getRemainingCriteria()) {
            player.getAdvancements().award(advancement, criterion);
        }
    }

    private static AdvancementProgress progress(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return null;
        }
        Advancement advancement = server.getAdvancements().getAdvancement(DEFEAT_ID);
        if (advancement == null) {
            return null;
        }
        return player.getAdvancements().getOrStartProgress(advancement);
    }
}
