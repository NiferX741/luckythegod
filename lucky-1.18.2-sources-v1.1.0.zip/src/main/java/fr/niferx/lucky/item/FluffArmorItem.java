package fr.niferx.lucky.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import fr.niferx.lucky.client.FluffArmorModel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.client.IItemRenderProperties;

import javax.annotation.Nullable;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class FluffArmorItem extends ArmorItem {
    /** Two extra hearts on each piece. UUIDs differ per slot so the bonuses stack. */
    private static final Map<EquipmentSlot, UUID> HEALTH_IDS = Map.of(
            EquipmentSlot.FEET, UUID.fromString("6a1c0e40-7b21-4d5a-9c10-f11a0b220001"),
            EquipmentSlot.LEGS, UUID.fromString("6a1c0e40-7b21-4d5a-9c10-f11a0b220002"),
            EquipmentSlot.CHEST, UUID.fromString("6a1c0e40-7b21-4d5a-9c10-f11a0b220003"),
            EquipmentSlot.HEAD, UUID.fromString("6a1c0e40-7b21-4d5a-9c10-f11a0b220004")
    );

    private final EquipmentSlot slot;

    public FluffArmorItem(EquipmentSlot slot, Properties properties) {
        super(FluffArmorMaterial.FLUFF, slot, properties);
        this.slot = slot;
    }

    @Override
    public boolean isFireResistant() {
        return true;
    }

    @Override
    public void initializeClient(Consumer<IItemRenderProperties> consumer) {
        consumer.accept(new IItemRenderProperties() {
            private HumanoidModel<?> model;

            @Override
            @SuppressWarnings({"rawtypes", "unchecked"})
            public HumanoidModel<?> getArmorModel(LivingEntity entity, ItemStack stack, EquipmentSlot slot,
                                                   HumanoidModel<?> defaultModel) {
                if (this.model == null) {
                    this.model = new FluffArmorModel<>(
                            Minecraft.getInstance().getEntityModels().bakeLayer(FluffArmorModel.LAYER));
                }
                defaultModel.copyPropertiesTo((HumanoidModel) this.model);
                showOnly(this.model, slot);
                ((FluffArmorModel<?>) this.model).setCustomVisibility(slot);
                return this.model;
            }

            private void showOnly(HumanoidModel<?> armor, EquipmentSlot slot) {
                armor.setAllVisible(false);
                switch (slot) {
                    case HEAD -> {
                        armor.head.visible = true;
                        armor.hat.visible = true;
                    }
                    case CHEST -> {
                        armor.body.visible = true;
                        armor.rightArm.visible = true;
                        armor.leftArm.visible = true;
                    }
                    case LEGS -> {
                        armor.body.visible = true;
                        armor.rightLeg.visible = true;
                        armor.leftLeg.visible = true;
                    }
                    case FEET -> {
                        armor.rightLeg.visible = true;
                        armor.leftLeg.visible = true;
                    }
                    default -> {
                    }
                }
            }
        });
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        Multimap<Attribute, AttributeModifier> modifiers = HashMultimap.create(super.getDefaultAttributeModifiers(slot));
        if (slot == this.slot) {
            modifiers.put(Attributes.MAX_HEALTH, new AttributeModifier(
                    HEALTH_IDS.get(slot), "Lucky fluff health", 4.0D, AttributeModifier.Operation.ADDITION));
        }
        return modifiers;
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
        if (level.isClientSide || !(entity instanceof Player player) || player.isSpectator()) {
            return;
        }
        if (player.getItemBySlot(this.slot) != stack || player.tickCount % 40 != 0) {
            return;
        }
        if (!wearingFullSet(player)) {
            return;
        }
        grant(player, MobEffects.DAMAGE_BOOST, 1);
        grant(player, MobEffects.MOVEMENT_SPEED, 1);
        grant(player, MobEffects.DAMAGE_RESISTANCE, 1);
        grant(player, MobEffects.REGENERATION, 0);
        grant(player, MobEffects.LUCK, 1);
    }

    private static void grant(Player player, net.minecraft.world.effect.MobEffect effect, int amplifier) {
        player.addEffect(new MobEffectInstance(effect, 120, amplifier, false, false, true));
    }

    public static boolean wearingFullSet(Player player) {
        return isFluff(player.getItemBySlot(EquipmentSlot.HEAD))
                && isFluff(player.getItemBySlot(EquipmentSlot.CHEST))
                && isFluff(player.getItemBySlot(EquipmentSlot.LEGS))
                && isFluff(player.getItemBySlot(EquipmentSlot.FEET));
    }

    private static boolean isFluff(ItemStack stack) {
        return stack.getItem() instanceof FluffArmorItem;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(new TranslatableComponent("item.lucky.fluff_armor.tooltip").withStyle(ChatFormatting.GRAY));
        tooltip.add(new TranslatableComponent("item.lucky.fluff_armor.hearts").withStyle(ChatFormatting.GRAY));
        tooltip.add(new TranslatableComponent("item.lucky.fluff_armor.set").withStyle(ChatFormatting.GOLD));
    }
}
