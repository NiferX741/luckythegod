package fr.niferx.lucky.item;

import fr.niferx.lucky.LuckyProgress;
import fr.niferx.lucky.entity.LuckyCompanionEntity;
import fr.niferx.lucky.entity.LuckyEntity;
import fr.niferx.lucky.registry.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

public class LuckyWhistleItem extends Item {
    private static final String COMPANION_KEY = LuckyCompanionEntity.COMPANION_KEY;

    public LuckyWhistleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide) {
            return InteractionResultHolder.success(stack);
        }
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.fail(stack);
        }

        boolean defeated = LuckyProgress.hasDefeated(serverPlayer);
        if (defeated && player.isShiftKeyDown()) {
            return summonBoss(server, serverPlayer, stack, false);
        }
        if (defeated) {
            return callCompanion(server, serverPlayer, stack);
        }
        return summonBoss(server, serverPlayer, stack, true);
    }

    private InteractionResultHolder<ItemStack> summonBoss(ServerLevel level, ServerPlayer player, ItemStack stack, boolean consume) {
        if (level.getDifficulty() == net.minecraft.world.Difficulty.PEACEFUL) {
            tell(player, "item.lucky.whistle.peaceful");
            return InteractionResultHolder.fail(stack);
        }
        if (!level.getEntitiesOfClass(LuckyEntity.class, player.getBoundingBox().inflate(64.0D)).isEmpty()) {
            tell(player, "item.lucky.whistle.already");
            player.getCooldowns().addCooldown(this, 20);
            return InteractionResultHolder.fail(stack);
        }

        double[] spot = placeNear(level, player);
        BlockPos pos = new BlockPos(spot[0], spot[1], spot[2]);
        LuckyEntity lucky = ModEntities.LUCKY.get().create(level);
        if (lucky == null) {
            return InteractionResultHolder.fail(stack);
        }
        lucky.moveTo(spot[0], spot[1], spot[2], player.getYRot() + 180.0F, 0.0F);
        lucky.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.MOB_SUMMONED, null, null);
        level.addFreshEntity(lucky);
        lucky.setTarget(player);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.NOTE_BLOCK_FLUTE, SoundSource.PLAYERS, 1.0F, 1.7F);
        lucky.playSound(SoundEvents.WOLF_AMBIENT, 1.4F, 1.35F);

        if (consume && !player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        player.getCooldowns().addCooldown(this, 40);
        tell(player, consume ? "item.lucky.whistle.summon" : "item.lucky.whistle.rematch");
        return InteractionResultHolder.consume(stack);
    }

    private InteractionResultHolder<ItemStack> callCompanion(ServerLevel level, ServerPlayer player, ItemStack stack) {
        LuckyCompanionEntity existing = findCompanion(level, player);
        if (existing != null) {
            recall(level, player, existing);
        } else {
            LuckyCompanionEntity dog = summonCompanion(level, player);
            if (dog == null) {
                return InteractionResultHolder.fail(stack);
            }
            remember(player, dog);
            level.sendParticles(ParticleTypes.HEART, dog.getX(), dog.getY() + 0.7D, dog.getZ(),
                    7, 0.35D, 0.3D, 0.35D, 0.0D);
            tell(player, "item.lucky.whistle.companion");
        }
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.NOTE_BLOCK_FLUTE, SoundSource.PLAYERS, 1.0F, 1.85F);
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.consume(stack);
    }

    @Nullable
    private static LuckyCompanionEntity findCompanion(ServerLevel level, ServerPlayer player) {
        CompoundTag data = player.getPersistentData();
        if (!data.hasUUID(COMPANION_KEY)) {
            return null;
        }
        UUID id = data.getUUID(COMPANION_KEY);
        for (ServerLevel world : level.getServer().getAllLevels()) {
            Entity entity = world.getEntity(id);
            if (entity instanceof LuckyCompanionEntity dog && dog.isAlive() && dog.isOwnedBy(player)) {
                return dog;
            }
        }
        return null;
    }

    private static void remember(ServerPlayer player, LuckyCompanionEntity dog) {
        player.getPersistentData().putUUID(COMPANION_KEY, dog.getUUID());
    }

    private static void recall(ServerLevel level, ServerPlayer player, LuckyCompanionEntity dog) {
        boolean here = dog.level == level && dog.distanceToSqr(player) < 8.0D * 8.0D;
        if (dog.level != level) {
            float health = dog.getHealth();
            dog.discard();
            LuckyCompanionEntity fresh = summonCompanion(level, player);
            if (fresh != null) {
                fresh.setHealth(Math.min(fresh.getMaxHealth(), Math.max(health, 8.0F)));
                remember(player, fresh);
                level.sendParticles(ParticleTypes.HEART, fresh.getX(), fresh.getY() + 0.7D, fresh.getZ(),
                        6, 0.3D, 0.25D, 0.3D, 0.0D);
            }
            tell(player, "item.lucky.whistle.recall");
            return;
        }
        dog.setOrderedToSit(false);
        dog.setTarget(null);
        if (!here) {
            double[] spot = placeNear(level, player);
            dog.teleportTo(spot[0], spot[1], spot[2]);
            dog.moveTo(spot[0], spot[1], spot[2], player.getYRot() + 180.0F, 0.0F);
            dog.setDeltaMovement(Vec3.ZERO);
            dog.fallDistance = 0.0F;
            dog.getNavigation().stop();
            level.sendParticles(ParticleTypes.HEART, spot[0], spot[1] + 0.7D, spot[2], 5, 0.3D, 0.25D, 0.3D, 0.0D);
            tell(player, "item.lucky.whistle.recall");
        } else {
            tell(player, "item.lucky.whistle.here");
        }
    }

    @Nullable
    private static LuckyCompanionEntity summonCompanion(ServerLevel level, ServerPlayer player) {
        double[] spot = placeNear(level, player);
        BlockPos pos = new BlockPos(spot[0], spot[1], spot[2]);
        LuckyCompanionEntity dog = ModEntities.LUCKY_COMPANION.get().create(level);
        if (dog == null) {
            return null;
        }
        dog.moveTo(spot[0], spot[1], spot[2], player.getYRot() + 180.0F, 0.0F);
        dog.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), MobSpawnType.MOB_SUMMONED, null, null);
        dog.tame(player);
        level.addFreshEntity(dog);
        dog.playSound(SoundEvents.WOLF_AMBIENT, 1.1F, 1.5F);
        return dog;
    }

    private static double[] placeNear(Level level, Player player) {
        Vec3 look = player.getLookAngle();
        double x = player.getX() + look.x * 2.2D;
        double y = player.getY();
        double z = player.getZ() + look.z * 2.2D;
        BlockPos pos = new BlockPos(x, y, z);
        if (level.getBlockState(pos).getMaterial().blocksMotion()
                || level.getBlockState(pos.above()).getMaterial().blocksMotion()) {
            return new double[]{player.getX(), player.getY(), player.getZ()};
        }
        return new double[]{x, y, z};
    }

    private static void tell(Player player, String key) {
        player.displayClientMessage(new TranslatableComponent(key), true);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(new TranslatableComponent("item.lucky.whistle.tooltip").withStyle(ChatFormatting.GRAY));
        tooltip.add(new TranslatableComponent("item.lucky.whistle.tooltip.companion").withStyle(ChatFormatting.GRAY));
    }
}
