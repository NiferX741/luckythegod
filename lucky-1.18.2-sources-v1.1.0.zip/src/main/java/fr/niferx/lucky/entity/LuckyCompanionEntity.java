package fr.niferx.lucky.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LeapAtTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Ghast;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

import javax.annotation.Nullable;

/**
 * The same spitz, after the fight. He follows, sits, and bites whatever is rude to his person.
 */
public class LuckyCompanionEntity extends TamableAnimal {
    public static final String COMPANION_KEY = "LuckyCompanion";

    private static final EntityDataAccessor<Boolean> DATA_BARKING =
            SynchedEntityData.defineId(LuckyCompanionEntity.class, EntityDataSerializers.BOOLEAN);

    private int barkCooldown = 30;
    private int barkAnim;

    @SuppressWarnings("deprecation")
    public LuckyCompanionEntity(EntityType<? extends LuckyCompanionEntity> type, Level level) {
        super(type, level);
        this.xpReward = 0;
        this.setPersistenceRequired();
        this.maxUpStep = 1.05F;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return TamableAnimal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 80.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.36D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.45D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BARKING, false);
    }

    public boolean isBarking() {
        return this.entityData.get(DATA_BARKING);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new LeapAtTargetGoal(this, 0.42F));
        this.goalSelector.addGoal(4, new MeleeAttackGoal(this, 1.25D, true));
        this.goalSelector.addGoal(5, new FollowOwnerGoal(this, 1.2D, 7.0F, 2.0F, false));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.9D));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(8, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
        this.targetSelector.addGoal(3, new HurtByTargetGoal(this).setAlertOthers());
        this.targetSelector.addGoal(4, new NearestAttackableTargetGoal<>(this, LivingEntity.class, 10, true, false,
                LuckyCompanionEntity::isHuntTarget));
    }

    private static boolean isHuntTarget(LivingEntity living) {
        if (!(living instanceof Enemy) || !living.isAlive() || living.isSpectator()) {
            return false;
        }
        if (living instanceof Creeper || living instanceof Ghast || living instanceof LuckyCompanionEntity) {
            return false;
        }
        return !(living instanceof TamableAnimal tame && tame.isTame());
    }

    @Override
    public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
        if (target == owner || this.isOwnedBy(target)) {
            return false;
        }
        if (target instanceof Creeper || target instanceof Ghast || target instanceof LuckyCompanionEntity) {
            return false;
        }
        if (target instanceof TamableAnimal tame && tame.isTame() && tame.getOwner() == owner) {
            return false;
        }
        if (target instanceof Player player && owner instanceof Player ownerPlayer && !ownerPlayer.canHarmPlayer(player)) {
            return false;
        }
        return true;
    }

    @Override
    public boolean canAttack(LivingEntity target) {
        if (this.isOwnedBy(target)) {
            return false;
        }
        return super.canAttack(target) && this.wantsToAttack(target, this.getOwner() == null ? this : this.getOwner());
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level.isClientSide) {
            if (this.isBarking() && this.tickCount % 2 == 0) {
                this.level.addParticle(ParticleTypes.CLOUD,
                        this.getX() + (this.random.nextDouble() - 0.5D) * 0.4D,
                        this.getY() + 0.5D,
                        this.getZ() + (this.random.nextDouble() - 0.5D) * 0.4D,
                        0.0D, 0.02D, 0.0D);
            }
            return;
        }
        if (this.barkAnim > 0) {
            this.barkAnim--;
            if (this.barkAnim == 0) {
                this.entityData.set(DATA_BARKING, false);
            }
        }
        if (this.tickCount % 40 == 0 && this.getTarget() == null && this.getHealth() < this.getMaxHealth()) {
            this.heal(1.0F);
        }
        if (this.tickCount % 100 == 0 && this.isTame() && this.getOwner() instanceof ServerPlayer owner) {
            CompoundTag data = owner.getPersistentData();
            if (data.hasUUID(COMPANION_KEY) && !this.getUUID().equals(data.getUUID(COMPANION_KEY))) {
                this.discard();
                return;
            }
        }
        this.tickBark();
    }

    private void tickBark() {
        if (this.barkCooldown > 0) {
            this.barkCooldown--;
        }
        if (this.isOrderedToSit() || this.barkCooldown > 0) {
            return;
        }
        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive() || this.distanceToSqr(target) > 36.0D) {
            return;
        }
        this.bark(target);
        this.barkCooldown = 80;
        this.barkAnim = 12;
        this.entityData.set(DATA_BARKING, true);
    }

    private void bark(LivingEntity target) {
        this.getLookControl().setLookAt(target, 40.0F, 40.0F);
        this.playSound(SoundEvents.WOLF_AMBIENT, 1.1F, 1.55F);
        if (this.level instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY() + 0.45D, this.getZ(),
                    10, 0.4D, 0.15D, 0.4D, 0.02D);
        }
        for (LivingEntity living : this.level.getEntitiesOfClass(LivingEntity.class, this.getBoundingBox().inflate(4.2D), this::isFoe)) {
            living.hurt(DamageSource.mobAttack(this), 6.0F);
            living.knockback(0.55D, this.getX() - living.getX(), this.getZ() - living.getZ());
            living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 30, 0));
        }
    }

    private boolean isFoe(LivingEntity living) {
        if (living == this || !living.isAlive() || living.isSpectator() || this.isOwnedBy(living)) {
            return false;
        }
        LivingEntity owner = this.getOwner();
        if (owner != null && !this.wantsToAttack(living, owner)) {
            return false;
        }
        return living instanceof Enemy || living == this.getTarget();
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.isOwnedBy(player)) {
            if (!this.level.isClientSide) {
                this.setOrderedToSit(!this.isOrderedToSit());
                this.setTarget(null);
                this.getNavigation().stop();
                this.setDeltaMovement(Vec3.ZERO);
            }
            return InteractionResult.sidedSuccess(this.level.isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void tame(Player player) {
        super.tame(player);
        this.setPersistenceRequired();
        this.setOrderedToSit(false);
        this.setHealth(this.getMaxHealth());
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt) {
            this.playSound(SoundEvents.FOX_BITE, 0.65F, 1.4F);
        }
        return hurt;
    }

    @Override
    public boolean causeFallDamage(float distance, float damageMultiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        return null;
    }

    @Override
    public boolean canBeLeashed(Player player) {
        return this.isOwnedBy(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public void checkDespawn() {
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return this.isOrderedToSit() ? null : SoundEvents.WOLF_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.WOLF_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.WOLF_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 1.45F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setPersistenceRequired();
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
