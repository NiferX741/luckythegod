package fr.niferx.lucky.entity;

import fr.niferx.lucky.registry.ModEntities;
import fr.niferx.lucky.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public class SqueakyBallEntity extends ThrowableItemProjectile {
    private int bounces;
    private int lastBounceTick = -10;
    private boolean struck;
    private float damage = 3.0F;

    public SqueakyBallEntity(EntityType<? extends SqueakyBallEntity> type, Level level) {
        super(type, level);
    }

    public SqueakyBallEntity(Level level, LivingEntity owner) {
        super(ModEntities.SQUEAKY_BALL.get(), owner, level);
    }

    public void setDamage(float damage) {
        this.damage = damage;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SQUEAKY_BALL.get();
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        if (entity == this.getOwner() || entity instanceof LuckyEntity || entity instanceof LuckyPupEntity) {
            return false;
        }
        return super.canHitEntity(entity);
    }

    @Override
    protected float getGravity() {
        return 0.05F;
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level.isClientSide && this.tickCount > 160) {
            this.pop(true);
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity hit = result.getEntity();
        Entity owner = this.getOwner();
        if (hit == owner || hit instanceof LuckyEntity || hit instanceof LuckyPupEntity) {
            return;
        }
        if (hit instanceof LivingEntity living) {
            living.hurt(DamageSource.thrown(this, owner), this.damage);
            this.struck = true;
            this.playSound(SoundEvents.SLIME_SQUISH_SMALL, 1.0F, 1.85F);
            this.pop(false);
        }
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.tickCount - this.lastBounceTick < 2) {
            return;
        }
        this.lastBounceTick = this.tickCount;
        Vec3 normal = Vec3.atLowerCornerOf(result.getDirection().getNormal());
        this.setPos(this.getX() + normal.x * 0.08D, this.getY() + normal.y * 0.08D, this.getZ() + normal.z * 0.08D);
        Vec3 motion = this.getDeltaMovement();
        Vec3 reflected = motion.subtract(normal.scale(2.0D * motion.dot(normal))).scale(0.62D);
        this.setDeltaMovement(reflected);
        this.playSound(SoundEvents.SLIME_SQUISH_SMALL, 0.55F, 1.7F + this.random.nextFloat() * 0.2F);
        this.bounces++;
        if (this.bounces > 5 || reflected.lengthSqr() < 0.012D) {
            this.pop(true);
        }
    }

    private void pop(boolean canReturn) {
        if (this.level instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.CLOUD, this.getX(), this.getY(), this.getZ(), 4, 0.1D, 0.1D, 0.1D, 0.01D);
        }
        if (canReturn && !this.struck && this.getOwner() instanceof Player && !this.getItem().isEmpty()) {
            this.spawnAtLocation(this.getItem().copy());
        }
        this.discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Bounces", this.bounces);
        tag.putBoolean("Struck", this.struck);
        tag.putFloat("Damage", this.damage);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.bounces = tag.getInt("Bounces");
        this.struck = tag.getBoolean("Struck");
        if (tag.contains("Damage")) {
            this.damage = tag.getFloat("Damage");
        }
    }

    @Override
    public Packet<?> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
