package fr.niferx.lucky.registry;

import fr.niferx.lucky.LuckyMod;
import fr.niferx.lucky.item.FluffArmorItem;
import fr.niferx.lucky.item.LuckyWhistleItem;
import fr.niferx.lucky.item.SqueakyBallItem;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TranslatableComponent;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, LuckyMod.MOD_ID);

    public static final RegistryObject<Item> WHISTLE = ITEMS.register("whistle",
            () -> new LuckyWhistleItem(new Item.Properties().tab(LuckyMod.TAB).stacksTo(1).rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> COLLAR = ITEMS.register("collar",
            () -> new fr.niferx.lucky.item.CollarItem(new Item.Properties().tab(LuckyMod.TAB).stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> FLUFF = ITEMS.register("fluff",
            () -> new Item(new Item.Properties().tab(LuckyMod.TAB)) {
                @Override
                public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
                    tooltip.add(new TranslatableComponent("item.lucky.fluff.tooltip").withStyle(ChatFormatting.GRAY));
                }
            });

    public static final RegistryObject<Item> FLUFF_HELMET = ITEMS.register("fluff_helmet",
            () -> new FluffArmorItem(EquipmentSlot.HEAD, armorProperties()));

    public static final RegistryObject<Item> FLUFF_CHESTPLATE = ITEMS.register("fluff_chestplate",
            () -> new FluffArmorItem(EquipmentSlot.CHEST, armorProperties()));

    public static final RegistryObject<Item> FLUFF_LEGGINGS = ITEMS.register("fluff_leggings",
            () -> new FluffArmorItem(EquipmentSlot.LEGS, armorProperties()));

    public static final RegistryObject<Item> FLUFF_BOOTS = ITEMS.register("fluff_boots",
            () -> new FluffArmorItem(EquipmentSlot.FEET, armorProperties()));

    public static final RegistryObject<Item> SQUEAKY_BALL = ITEMS.register("squeaky_ball",
            () -> new SqueakyBallItem(new Item.Properties().tab(LuckyMod.TAB).stacksTo(16)));

    public static final RegistryObject<Item> LUCKY_SPAWN_EGG = ITEMS.register("lucky_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.LUCKY, 0xF4F1EA, 0xC4303A,
                    new Item.Properties().tab(LuckyMod.TAB)));

    public static final RegistryObject<Item> LUCKY_PUP_SPAWN_EGG = ITEMS.register("lucky_pup_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.LUCKY_PUP, 0xFFFDF8, 0xE7B341,
                    new Item.Properties().tab(LuckyMod.TAB)));

    private static Item.Properties armorProperties() {
        return new Item.Properties().tab(LuckyMod.TAB).stacksTo(1).rarity(Rarity.EPIC);
    }

    private ModItems() {
    }
}
