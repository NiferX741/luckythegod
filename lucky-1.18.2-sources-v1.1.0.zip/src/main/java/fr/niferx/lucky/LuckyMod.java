package fr.niferx.lucky;

import fr.niferx.lucky.config.LuckyConfig;
import fr.niferx.lucky.registry.ModEntities;
import fr.niferx.lucky.registry.ModItems;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(LuckyMod.MOD_ID)
public class LuckyMod {
    public static final String MOD_ID = "lucky";

    public static final CreativeModeTab TAB = new CreativeModeTab(MOD_ID) {
        @Override
        public ItemStack makeIcon() {
            return new ItemStack(ModItems.WHISTLE.get());
        }
    };

    public LuckyMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, LuckyConfig.SPEC);

        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        bus.addListener(ModEntities::onAttributeCreation);

        MinecraftForge.EVENT_BUS.register(this);
    }
}
