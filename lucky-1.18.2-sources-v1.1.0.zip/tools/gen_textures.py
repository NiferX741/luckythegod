#!/usr/bin/env python3
"""Generate Lucky's entity, item, and mod-list textures."""

import random
import struct
import zlib
from pathlib import Path

ROOT = Path("/workspace/src/main/resources")


def write_png(path: Path, w: int, h: int, rgba: bytearray) -> None:
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw.extend(rgba[y * w * 4:(y + 1) * w * 4])

    def chunk(tag: bytes, data: bytes) -> bytes:
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)


def fur_pixel(x: int, y: int, rose: float = 0.0):
    n = random.Random(x * 734287 + y * 912763 + 11).randrange(-16, 10)
    r = max(0, min(255, 250 + n))
    g = max(0, min(255, 246 + n - 2))
    b = max(0, min(255, 238 + n - 8))
    if rose:
        r = int(r * (1 - rose) + 255 * rose)
        g = int(g * (1 - rose) + 196 * rose)
        b = int(b * (1 - rose) + 204 * rose)
    return r, g, b, 255


def fill_rect(buf, w, x0, y0, x1, y1, color):
    h = len(buf) // (w * 4)
    x0 = max(0, x0)
    y0 = max(0, y0)
    x1 = min(w, x1)
    y1 = min(h, y1)
    for y in range(y0, y1):
        for x in range(x0, x1):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes(color)


def entity_texture(rose: float = 0.0) -> bytearray:
    w, h = 128, 64
    buf = bytearray(w * h * 4)
    for y in range(h):
        for x in range(w):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes(fur_pixel(x, y, rose))
    # Solid islands for the small feature cubes. Fur cubes do not sample these.
    fill_rect(buf, w, 0, 50, 40, 64, (196, 48, 58, 255))       # collar
    fill_rect(buf, w, 42, 50, 58, 64, (227, 179, 65, 255))      # tag
    fill_rect(buf, w, 60, 50, 80, 64, (242, 168, 184, 255))     # tongue + inner ear
    fill_rect(buf, w, 82, 50, 96, 64, (18, 16, 22, 255))        # eyes
    fill_rect(buf, w, 84, 51, 86, 53, (255, 255, 255, 255))     # catchlight
    fill_rect(buf, w, 98, 50, 110, 64, (28, 24, 30, 255))       # nose
    brow = (120, 64, 72, 255) if rose else (74, 55, 47, 255)
    fill_rect(buf, w, 112, 50, 128, 64, brow)
    return buf


def blit_row(buf, w, y, row, palette):
    for x, ch in enumerate(row):
        color = palette.get(ch)
        if color is None:
            continue
        i = (y * w + x) * 4
        buf[i:i + 4] = bytes(color)


def sprite(rows, palette):
    h = len(rows)
    w = len(rows[0])
    for row in rows:
        if len(row) != w:
            raise ValueError(f"sprite row width {len(row)} != {w}: {row}")
    buf = bytearray(w * h * 4)
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, palette)
    return buf


def item_whistle():
    # Bone whistle with a periwinkle lanyard ring and a gold cap, the collar's colors.
    pal = {
        "o": (102, 78, 58, 255),
        "d": (176, 150, 118, 255),
        "B": (255, 246, 232, 255),
        "h": (255, 252, 246, 255),
        "k": (58, 42, 36, 255),
        "c": (184, 192, 247, 255),
        "G": (255, 208, 64, 255),
        "g": (176, 118, 24, 255),
    }
    rows = [
        "................",
        ".......cc.......",
        "......c..c......",
        "......cGGc......",
        "..odddddddddo...",
        ".oBBBBBBBBBBBo..",
        "oodBBhhhhhhBBBo.",
        "oBBBkkkkkkkkBBo.",
        "oodBBhhhhhhBBBo.",
        ".oBBBBBBBBBBBo..",
        "..odddddddddo...",
        "................",
        "................",
        "................",
        "................",
        "................",
    ]
    return sprite(rows, pal)


def item_collar():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "R": (196, 48, 58, 255),
        "D": (140, 28, 38, 255),
        "G": (227, 179, 65, 255),
        "g": (168, 122, 36, 255),
        "W": (255, 236, 170, 255),
    }
    rows = [
        "................",
        "................",
        "..DDDDDDDDDDD...",
        ".DRRRRRRRRRRRD..",
        ".DRRRRRRRRRRRD..",
        ".DRRRGGGRRRRRD..",
        "..DRRRGRRRRRD...",
        "....DDDDDDD.....",
        "......gGg.......",
        "......gWg.......",
        "......gGg.......",
        ".......g........",
        "................",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_ball():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "R": (204, 42, 52, 255),
        "D": (150, 24, 34, 255),
        "W": (255, 220, 220, 255),
        "K": (48, 16, 20, 255),
        "L": (255, 170, 170, 255),
    }
    rows = [
        "................",
        "................",
        ".....DDDDD......",
        "....DRRRRRRD....",
        "...DRWWLRRRRD...",
        "...DRRRRRRRRD...",
        "..DRRRRRRRRRRD..",
        "..DRRRKKKRRRRD..",
        "..DRRRRRRRRRRD..",
        "...DRRRRRRRRD...",
        "...DRRRRRRRRD...",
        "....DRRRRRRD....",
        ".....DDDDD......",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_fluff():
    w = h = 16
    buf = bytearray(w * h * 4)
    pal = {
        "W": (255, 252, 248, 255),
        "C": (236, 228, 216, 255),
        "S": (214, 204, 190, 255),
    }
    rows = [
        "................",
        "................",
        "....WWWW........",
        "...WWCCWWW......",
        "..WWCCCCWWWW....",
        ".WWCCCWWCCCWW...",
        ".WCCCWWWWCCSW...",
        "..WWCCCCCCSWW...",
        "...WWCCCSSWW....",
        "....WWSSWW......",
        ".....WWW........",
        "................",
        "................",
        "................",
        "................",
        "................",
    ]
    for y, row in enumerate(rows):
        blit_row(buf, w, y, row, pal)
    return buf


def item_armor(kind):
    # Soft, rounded icons inspired by Lucky: cream fur, pink ears and cheeks,
    # tiny chocolate eyes, a periwinkle collar and a little heart-shaped tag.
    pal = {
        "o": (188, 178, 174, 255),
        "W": (255, 248, 234, 255),
        "w": (237, 222, 207, 255),
        "s": (217, 202, 195, 255),
        "P": (255, 204, 171, 255),
        "p": (236, 169, 131, 255),
        "R": (255, 219, 203, 255),
        "B": (82, 58, 48, 255),
        "b": (123, 87, 69, 255),
        "h": (255, 255, 255, 255),
        "n": (65, 49, 45, 255),
        "T": (244, 92, 112, 255),
        "c": (197, 202, 255, 255),
        "C": (143, 153, 226, 255),
        "G": (255, 218, 93, 255),
        "g": (221, 163, 45, 255),
        "D": (173, 173, 183, 255),
        "d": (130, 130, 143, 255),
        "L": (205, 199, 192, 255),
        "K": (72, 65, 62, 255),
    }
    sheets = {
        "helmet": [
            "...oWo....oWo...",
            "..oWKo....oKWo..",
            "..oWWWooooWWWo..",
            ".oWWWWWWWWWWWWo.",
            ".oWWWBWWWWBWWWo.",
            ".oWWWWWWWWWWWWo.",
            ".oWWWWwwwwWWWWo.",
            ".oWWWwLLLLwWWWo.",
            ".oWWWLnnnnLWWWo.",
            ".oWWWLnnnnLWWWo.",
            ".oWWWwLTTwWWWWo.",
            "..oWWWwLLwWWWo..",
            "...oWWWWWWWWo...",
            "...ooKKKKKKoo...",
            "..oWWWWWWWWWWo..",
            "................",
        ],
        "chest": [
            "................",
            "..oooo....oooo..",
            ".oWWWWo..oWWWWo.",
            ".oWGgWo..oWgGWo.",
            ".oWGGWooooWGGWo.",
            ".oWWWWWWWWWWWWo.",
            ".oWWWwKKKKwWWWo.",
            ".oWWWKWWWWKWWWo.",
            ".oWWWKWWWWKWWWo.",
            ".oWWWwKKKKwWWWo.",
            ".oWWWWLLLLWWWWo.",
            "..oWWWLWWLWWWo..",
            "...oWWLLLLWWo...",
            ".oWWWWWWWWWWWWo.",
            "...oWWWWWWWWo...",
            "....oooooooo....",
        ],
        "legs": [
            "................",
            "....oKKKKKKo....",
            "...oLWWWWWWLo...",
            "...oWWWWWWWWo...",
            "...oWW.WW.WWo...",
            "...oWW.WW.WWo...",
            "...owW.WW.WWo...",
            "...oWW.WW.WWo...",
            "..oKLo.WW.oLKo..",
            "..oLWo.WW.oWLo..",
            "..oKLo.WW.oLKo..",
            "...oWW.WW.WWo...",
            "...oWW....WWo...",
            "...oWW....WWo...",
            "...owW....Wwo...",
            "....oo....oo....",
            "................",
        ],
        "boots": [
            "................",
            "................",
            "..oooo....oooo..",
            ".oWWWWo..oWWWWo.",
            ".oWwwWo..oWwwWo.",
            ".oWWWWo..oWWWWo.",
            ".oWLLWo..oWLLWo.",
            ".oWKKWo..oWKKWo.",
            ".oWKKWo..oWKKWo.",
            ".oWWWWo..oWWWWo.",
            "..oooo....oooo..",
            "................",
            "................",
            "................",
            "................",
            "................",
        ],
    }
    return sprite(sheets[kind], pal)


def lerp_color(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3)) + (255,)


def paint_gradient(buf, tex_w, x, y, bw, bh, top, bottom):
    height = len(buf) // (tex_w * 4)
    for py in range(bh):
        t = 0 if bh <= 1 else py / (bh - 1)
        # Edges sit a little deeper in the shade, like the reference fur.
        color = lerp_color(top, bottom, t)
        for px in range(bw):
            edge = px == 0 or px == bw - 1 or py == bh - 1
            shaded = color
            if edge:
                shaded = lerp_color(color, bottom, 0.45)
            sx, sy = x + px, y + py
            if sx < 0 or sy < 0 or sx >= tex_w or sy >= height:
                continue
            i = (sy * tex_w + sx) * 4
            buf[i:i + 4] = bytes(shaded)


def stamp(buf, tex_w, x, y, rows, palette):
    blit_grid = rows
    height = len(buf) // (tex_w * 4)
    for dy, row in enumerate(blit_grid):
        for dx, ch in enumerate(row):
            color = palette.get(ch)
            if color is None:
                continue
            sx, sy = x + dx, y + dy
            if 0 <= sx < tex_w and 0 <= sy < height:
                i = (sy * tex_w + sx) * 4
                buf[i:i + 4] = bytes(color)


FUR_TOP = (255, 249, 236)
FUR_BOT = (229, 214, 203)
FACE = {
    ".": None,
    "W": (255, 248, 234, 255),
    "w": (237, 222, 207, 255),
    "P": (255, 204, 171, 255),
    "R": (255, 219, 203, 255),
    "B": (82, 58, 48, 255),
    "n": (65, 49, 45, 255),
    "T": (244, 92, 112, 255),
    "C": (197, 202, 255, 255),
    "c": (143, 153, 226, 255),
    "G": (255, 218, 93, 255),
    "g": (221, 163, 45, 255),
    "D": (173, 173, 183, 255),
    "d": (130, 130, 143, 255),
    "L": (205, 199, 192, 255),
    "K": (72, 65, 62, 255),
}
# 8x8, drawn the way it is seen on the helmet.
DOG_FACE = [
    "PPWWWWPP",
    "WWBWWBWW",
    "WWWWWWWW",
    "RWWWWWWR",
    "WWWnnWWW",
    "WWWTTWWW",
    "WwWWWWWw",
    "CCCCCCCC",
]
DOG_SIDE = [
    "WWWPPWWW",
    "WWPPPPWW",
    "WWPPPPWW",
    "WWWWWWWW",
    "RWWWWWWR",
    "wWWWWWWw",
    "WWWWWWWW",
    "CCCCCCCC",
]
DOG_TOP = [
    "WWWWWWWW",
    "WPPWWPPW",
    "WPPWWPPW",
    "WWWWWWWW",
    "WWWWWWWW",
    "WWWWWWWW",
    "WWWWWWWW",
    "WWWWWWWW",
]
DOG_BACK = [
    "WWWWWWWW",
    "WWWWWWWW",
    "wWWWWWWw",
    "wWWWWWWw",
    "wWWWWWWw",
    "wWWWWWWw",
    "WWWWWWWW",
    "CCCCCCCC",
]


def fill_box(buf, tex_w, u, v, bw, bh, bd, y0=0, y1=None, tops=True):
    """Soft white fur on a Minecraft cube. y0/y1 limit the side faces."""
    if y1 is None:
        y1 = bh
    if tops and y0 == 0 and y1 == bh:
        paint_gradient(buf, tex_w, u + bd, v, bw, bd, FUR_TOP, FUR_BOT)
        paint_gradient(buf, tex_w, u + bd + bw, v, bw, bd, FUR_TOP, FUR_BOT)
    span = y1 - y0
    paint_gradient(buf, tex_w, u, v + bd + y0, bd, span, FUR_TOP, FUR_BOT)
    paint_gradient(buf, tex_w, u + bd, v + bd + y0, bw, span, FUR_TOP, FUR_BOT)
    paint_gradient(buf, tex_w, u + bd + bw, v + bd + y0, bd, span, FUR_TOP, FUR_BOT)
    paint_gradient(buf, tex_w, u + bd + bw + bd, v + bd + y0, bw, span, FUR_TOP, FUR_BOT)


def paint_head(buf, tex_w, origin_u):
    # origin_u is 0 for the helmet and 32 for the outer hat.
    fill_box(buf, tex_w, origin_u, 0, 8, 8, 8)
    stamp(buf, tex_w, origin_u + 8, 8, DOG_FACE, FACE)       # front
    stamp(buf, tex_w, origin_u, 8, DOG_SIDE, FACE)           # player's right
    stamp(buf, tex_w, origin_u + 16, 8, DOG_SIDE, FACE)      # player's left
    stamp(buf, tex_w, origin_u + 24, 8, DOG_BACK, FACE)      # back
    stamp(buf, tex_w, origin_u + 16, 0, DOG_TOP, FACE)       # top


def paint_chest_details(buf, tex_w):
    collar = ["CCCCCCCC", "cccccccc"]
    tag = [
        "WWWWWWWW",
        "WWWGGWWW",
        "WWGGGGWW",
        "WWWGGWWW",
        "WWWWWWWW",
        "WWWWWWWW",
        "WWWWWWWW",
        "WwWWWWWw",
        "WwWWWWWw",
        "WWWWWWWW",
    ]
    # Front, back and both sides share the collar so it wraps the neck.
    stamp(buf, tex_w, 20, 20, collar, FACE)
    stamp(buf, tex_w, 20, 22, tag, FACE)
    stamp(buf, tex_w, 32, 20, collar, FACE)
    for x in (16, 28):
        stamp(buf, tex_w, x, 20, ["CCCC", "cccc"], FACE)


def paint_arm_paws(buf, tex_w):
    # Soft gray paws with a tiny pink pad, like Lucky's feet in the reference.
    for x, width in ((44, 4), (40, 4), (48, 4), (52, 4)):
        stamp(buf, tex_w, x, 29, ["DDDD", "DRRD", "dddd"], FACE)


def paint_boots(buf, tex_w):
    # Only the ankle and the paw. The rest of the leg stays transparent.
    fill_box(buf, tex_w, 0, 16, 4, 12, 4, y0=7, y1=12, tops=False)
    paint_gradient(buf, tex_w, 8, 16, 4, 4, (188, 186, 196), (132, 130, 144))  # sole
    cuff = ["CCCC", "WWWW", "WWWW", "DRRD", "dddd"]
    for x in (4, 0, 8, 12):
        stamp(buf, tex_w, x, 27, cuff, FACE)


def armor_layer(outer):
    # The vanilla armor UVs remain in the top-left 64x32 area. Extra room holds
    # the real 3D ears used by FluffArmorModel.
    tex_w = 128
    buf = bytearray(tex_w * 64 * 4)
    if outer:
        paint_head(buf, tex_w, 0)
        paint_head(buf, tex_w, 32)
        fill_box(buf, tex_w, 16, 16, 8, 12, 4)
        paint_chest_details(buf, tex_w)
        fill_box(buf, tex_w, 40, 16, 4, 12, 4)
        paint_arm_paws(buf, tex_w)
        paint_boots(buf, tex_w)
        # Ear base, rounded tip and inset peach-colored inner ear.
        paint_gradient(buf, tex_w, 64, 0, 11, 7, FUR_TOP, FUR_BOT)
        paint_gradient(buf, tex_w, 64, 8, 9, 5, FUR_TOP, FUR_BOT)
        paint_gradient(buf, tex_w, 76, 0, 7, 4, (255, 218, 188), (235, 166, 133))
        # Hood cheeks and protruding muzzle.
        paint_gradient(buf, tex_w, 64, 14, 15, 11, FUR_TOP, FUR_BOT)
        paint_gradient(buf, tex_w, 82, 0, 18, 7, (244, 222, 194), (207, 170, 139))
        stamp(buf, tex_w, 85, 3, [
            "WWWWWW",
            "WwwwwW",
            "wwwwww",
        ], FACE)
        stamp(buf, tex_w, 102, 0, [
            "KKKKKKKK",
            "KKKKKKKK",
            "KKKKKKKK",
            "KKKKKKKK",
        ], FACE)

        # Large fluffy neck ruff.
        paint_gradient(buf, tex_w, 64, 24, 32, 11, FUR_TOP, FUR_BOT)

        # Layered silver-white chest and waist plates with dark piping.
        paint_gradient(buf, tex_w, 64, 36, 20, 9, (242, 239, 232), (177, 171, 169))
        stamp(buf, tex_w, 65, 37, [
            "KKKKKKKKK",
            "KWWWWWWWK",
            "KWwwwwwWK",
            "KWwwwwwWK",
            "KWWWWWWWK",
            "KKKKKKKKK",
        ], FACE)
        paint_gradient(buf, tex_w, 86, 36, 21, 6, (242, 239, 232), (177, 171, 169))
        stamp(buf, tex_w, 87, 37, [
            "KKKKKKKKK",
            "KWWWWWWWK",
            "KKKKKKKKK",
        ], FACE)

        # Puffy shoulder guards. A tiny golden bone sits on each one.
        paint_gradient(buf, tex_w, 96, 14, 25, 12, FUR_TOP, FUR_BOT)
        stamp(buf, tex_w, 102, 20, [
            "GGWWGG",
            "WGGGGW",
            "WWGGWW",
            "WGGGGW",
            "GGWWGG",
        ], FACE)

        # Oversized furry wrist cuffs with a graphite trim.
        paint_gradient(buf, tex_w, 106, 28, 21, 10, FUR_TOP, FUR_BOT)
        stamp(buf, tex_w, 111, 33, [
            "KWWWK",
            "KwwwK",
            "KWWWK",
            "KKKKK",
        ], FACE)

        # Rounded knee plates and thick boot cuffs.
        paint_gradient(buf, tex_w, 64, 46, 13, 6, (231, 227, 219), (154, 149, 151))
        stamp(buf, tex_w, 65, 47, [
            "KLLLK",
            "KLWLK",
            "KLGLK",
            "KLLLK",
        ], FACE)
        paint_gradient(buf, tex_w, 78, 46, 21, 9, FUR_TOP, FUR_BOT)
        stamp(buf, tex_w, 83, 51, [
            "KWWWK",
            "KwwwK",
            "KKKKK",
        ], FACE)
    else:
        fill_box(buf, tex_w, 0, 16, 4, 12, 4)
        # Hips only, so the chestplate stays visible above the waistband.
        fill_box(buf, tex_w, 16, 16, 8, 12, 4, y0=8, y1=12, tops=False)
        stamp(buf, tex_w, 20, 28, ["CCCCCCCC", "cccccccc"], FACE)
        stamp(buf, tex_w, 16, 28, ["CCCC", "cccc"], FACE)
        stamp(buf, tex_w, 28, 28, ["CCCC", "cccc"], FACE)
        stamp(buf, tex_w, 32, 28, ["CCCCCCCC", "cccccccc"], FACE)
    return buf


def logo():
    """128x128 face for the mod list."""
    w = h = 128
    buf = bytearray(w * h * 4)
    # soft slate backdrop
    for y in range(h):
        for x in range(w):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes((46, 52, 64, 255))

    def disc(cx, cy, rx, ry, color):
        for y in range(h):
            for x in range(w):
                if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1:
                    i = (y * w + x) * 4
                    buf[i:i + 4] = bytes(color)

    def tri_ear(cx, top, half, height, color):
        for y in range(top, min(h, top + height)):
            t = (y - top) / height
            span = half * t
            for x in range(int(cx - span), int(cx + span) + 1):
                if 0 <= x < w:
                    i = (y * w + x) * 4
                    buf[i:i + 4] = bytes(color)

    disc(64, 74, 46, 42, (247, 244, 238, 255))
    tri_ear(34, 18, 16, 36, (245, 240, 232, 255))
    tri_ear(94, 18, 16, 36, (245, 240, 232, 255))
    tri_ear(34, 24, 8, 22, (242, 168, 184, 255))
    tri_ear(94, 24, 8, 22, (242, 168, 184, 255))
    disc(46, 70, 8, 10, (24, 20, 26, 255))
    disc(82, 70, 8, 10, (24, 20, 26, 255))
    disc(49, 67, 2, 2, (255, 255, 255, 255))
    disc(85, 67, 2, 2, (255, 255, 255, 255))
    disc(64, 86, 7, 5, (32, 26, 30, 255))
    disc(64, 98, 5, 3, (226, 130, 148, 255))
    # collar
    for y in range(108, 118):
        for x in range(28, 100):
            i = (y * w + x) * 4
            buf[i:i + 4] = bytes((196, 48, 58, 255))
    disc(64, 120, 5, 6, (227, 179, 65, 255))
    return buf


def main():
    entity = ROOT / "assets/lucky/textures/entity"
    item = ROOT / "assets/lucky/textures/item"
    write_png(entity / "lucky.png", 128, 64, entity_texture(0.0))
    write_png(entity / "lucky_enraged.png", 128, 64, entity_texture(0.14))
    write_png(item / "whistle.png", 16, 16, item_whistle())
    write_png(item / "collar.png", 16, 16, item_collar())
    write_png(item / "squeaky_ball.png", 16, 16, item_ball())
    write_png(item / "fluff.png", 16, 16, item_fluff())
    write_png(item / "fluff_helmet.png", 16, 16, item_armor("helmet"))
    write_png(item / "fluff_chestplate.png", 16, 16, item_armor("chest"))
    write_png(item / "fluff_leggings.png", 16, 16, item_armor("legs"))
    write_png(item / "fluff_boots.png", 16, 16, item_armor("boots"))
    armor = ROOT / "assets/lucky/textures/models/armor"
    write_png(armor / "fluff_layer_1.png", 128, 64, armor_layer(True))
    write_png(armor / "fluff_layer_2.png", 128, 64, armor_layer(False))
    write_png(ROOT / "logo.png", 128, 128, logo())
    print("textures written")


if __name__ == "__main__":
    main()
