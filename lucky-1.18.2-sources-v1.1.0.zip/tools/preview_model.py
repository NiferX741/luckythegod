#!/usr/bin/env python3
"""Orthographic preview of Lucky's cube model (Minecraft entity space)."""

import math
import struct
import zlib
from pathlib import Path

# Part: name, parent, (x, y, z), (rx, ry, rz), cubes [(ox, oy, oz, w, h, d, rgba)]

def C(r, g, b, a=255):
    return (r, g, b, a)

FUR = C(247, 244, 238)
FUR_DEEP = C(232, 224, 212)
RUFF = C(255, 252, 248)
HEAD = C(250, 248, 244)
EAR = C(245, 240, 232)
EAR_IN = C(242, 168, 184)
SNOUT = C(255, 250, 246)
NOSE = C(36, 32, 36)
EYE = C(22, 20, 24)
TONGUE = C(226, 130, 148)
COLLAR = C(196, 48, 58)
TAG = C(227, 179, 65)
LEG = C(236, 230, 220)
BROW = C(74, 55, 47)

# Round miniature spitz: ball body, big ruff, short muzzle, tail curled over the back.
# Positive X rotation lifts a part that extends toward +Z (tail). It lowers a part that extends toward -Z (snout).
PARTS = [
    ("body", None, (0.0, 16.4, 0.0), (0, 0, 0), [
        # main fluff ball
        (-6.0, -5.6, -5.5, 12.0, 10.6, 11.0, FUR),
        # side puff so the silhouette is rounder than a box
        (-7.0, -4.6, -4.2, 14.0, 8.4, 8.6, FUR_DEEP),
    ]),
    ("ruff", "body", (0.0, -3.6, -4.8), (0.35, 0, 0), [
        (-6.6, -3.6, -3.4, 13.2, 7.2, 6.6, RUFF),
    ]),
    ("head", "body", (0.0, -7.4, -3.2), (0.05, 0, 0), [
        (-4.0, -5.2, -3.8, 8.0, 6.0, 6.4, HEAD),
    ]),
    ("cheek_l", "head", (3.3, -2.0, -1.4), (0, 0.15, 0), [
        (0.0, -1.8, -1.8, 2.6, 3.6, 3.6, FUR),
    ]),
    ("cheek_r", "head", (-3.3, -2.0, -1.4), (0, -0.15, 0), [
        (-2.6, -1.8, -1.8, 2.6, 3.6, 3.6, FUR),
    ]),
    ("snout", "head", (0.0, -1.05, -3.6), (0.2, 0, 0), [
        (-1.45, -1.2, -2.3, 2.9, 2.15, 2.4, SNOUT),
    ]),
    ("nose", "head", (0.0, -1.7, -6.15), (0.15, 0, 0), [
        (-0.85, -0.7, -0.55, 1.7, 1.25, 0.8, NOSE),
    ]),
    ("tongue", "head", (0.0, 0.15, -5.15), (0.95, 0, 0), [
        (-0.55, 0.0, -0.9, 1.1, 0.4, 1.15, TONGUE),
    ]),
    ("ear_l", "head", (2.35, -4.7, -0.4), (-0.15, -0.2, 0.42), [
        (-1.15, -2.6, -0.7, 2.3, 2.8, 1.5, EAR),
    ]),
    ("ear_r", "head", (-2.35, -4.7, -0.4), (-0.15, 0.2, -0.42), [
        (-1.15, -2.6, -0.7, 2.3, 2.8, 1.5, EAR),
    ]),
    ("ear_l_in", "head", (2.35, -4.55, -0.95), (-0.15, -0.2, 0.42), [
        (-0.75, -1.9, -0.3, 1.5, 1.9, 0.4, EAR_IN),
    ]),
    ("ear_r_in", "head", (-2.35, -4.55, -0.95), (-0.15, 0.2, -0.42), [
        (-0.75, -1.9, -0.3, 1.5, 1.9, 0.4, EAR_IN),
    ]),
    ("eye_l", "head", (1.75, -3.05, -4.15), (0, 0, 0), [
        (-0.6, -0.8, -0.25, 1.25, 1.6, 0.45, EYE),
    ]),
    ("eye_r", "head", (-1.75, -3.05, -4.15), (0, 0, 0), [
        (-0.65, -0.8, -0.25, 1.25, 1.6, 0.45, EYE),
    ]),
    ("brow_l", "head", (1.85, -4.15, -3.65), (0, 0, 0.55), [
        (-0.95, -0.28, -0.25, 1.8, 0.5, 0.35, BROW),
    ]),
    ("brow_r", "head", (-1.85, -4.15, -3.65), (0, 0, -0.55), [
        (-0.85, -0.28, -0.25, 1.8, 0.5, 0.35, BROW),
    ]),
    ("collar", "body", (0.0, 0.4, -4.6), (0.55, 0, 0), [
        (-4.4, -1.15, -2.2, 8.8, 2.3, 4.4, COLLAR),
    ]),
    ("tag", "collar", (0.0, 1.2, -1.9), (0.35, 0, 0), [
        (-0.75, 0.0, -0.28, 1.5, 2.1, 0.55, TAG),
    ]),
    # Plume laid over the back. Children sit in an arc; wagging rotates the whole tail.
    ("tail", "body", (0.0, -4.0, 3.4), (0.15, 0, 0), [
        (-1.25, -3.1, -1.15, 2.5, 3.3, 2.5, FUR),
    ]),
    ("tail2", "tail", (0.0, -3.3, -1.5), (-0.15, 0, 0), [
        (-2.0, -2.15, -1.8, 4.0, 3.7, 3.5, FUR),
    ]),
    ("tail3", "tail", (0.0, -2.5, -4.2), (-0.25, 0, 0), [
        (-2.55, -1.9, -2.1, 5.1, 3.7, 4.0, RUFF),
    ]),
    ("leg_fl", "body", (2.7, 4.3, -2.4), (0, 0, 0), [
        (-1.05, 0.0, -1.05, 2.1, 3.4, 2.1, LEG),
    ]),
    ("leg_fr", "body", (-2.7, 4.3, -2.4), (0, 0, 0), [
        (-1.05, 0.0, -1.05, 2.1, 3.4, 2.1, LEG),
    ]),
    ("leg_bl", "body", (2.8, 4.3, 2.8), (0, 0, 0), [
        (-1.05, 0.0, -1.05, 2.1, 3.4, 2.1, LEG),
    ]),
    ("leg_br", "body", (-2.8, 4.3, 2.8), (0, 0, 0), [
        (-1.05, 0.0, -1.05, 2.1, 3.4, 2.1, LEG),
    ]),
]


def rot_x(p, a):
    if a == 0:
        return p
    ca, sa = math.cos(a), math.sin(a)
    x, y, z = p
    return (x, y * ca - z * sa, y * sa + z * ca)


def rot_y(p, a):
    if a == 0:
        return p
    ca, sa = math.cos(a), math.sin(a)
    x, y, z = p
    return (x * ca + z * sa, y, -x * sa + z * ca)


def rot_z(p, a):
    if a == 0:
        return p
    ca, sa = math.cos(a), math.sin(a)
    x, y, z = p
    return (x * ca - y * sa, x * sa + y * ca, z)


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


BY_NAME = {p[0]: p for p in PARTS}


def to_model(part_name, local):
    name = part_name
    p = local
    seen = 0
    while name is not None:
        _n, parent, pos, rot, _cubes = BY_NAME[name]
        p = rot_x(p, rot[0])
        p = rot_y(p, rot[1])
        p = rot_z(p, rot[2])
        p = add(p, pos)
        name = parent
        seen += 1
        if seen > 12:
            break
    return p


def visual(mx, my, mz):
    """Pixels, Y up, feet near 0. Matches entity renderer scale(-1,-1,1) + translate."""
    bx, by, bz = mx / 16.0, my / 16.0, mz / 16.0
    ty = by - 1.501
    vx = -bx * 16.0
    vy = -ty * 16.0
    vz = bz * 16.0
    return (vx, vy, vz)


def cube_faces(origin, size):
    ox, oy, oz = origin
    w, h, d = size
    x0, y0, z0 = ox, oy, oz
    x1, y1, z1 = ox + w, oy + h, oz + d
    # 8 corners
    c = [
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ]
    # faces as quads, with a name
    return [
        ("front", [c[0], c[1], c[2], c[3]]),  # -Z
        ("back", [c[5], c[4], c[7], c[6]]),
        ("top", [c[3], c[2], c[6], c[7]]),  # -Y in model = up visually? model smaller Y is up, so y0 is the upper face
        ("bottom", [c[4], c[5], c[1], c[0]]),
        ("left", [c[1], c[5], c[6], c[2]]),
        ("right", [c[4], c[0], c[3], c[7]]),
    ]


def shade(color, face):
    r, g, b, a = color
    mul = {
        "front": 1.0,
        "back": 0.78,
        "top": 1.08,
        "bottom": 0.72,
        "left": 0.9,
        "right": 0.84,
    }[face]
    def ch(v):
        return max(0, min(255, int(v * mul)))
    return (ch(r), ch(g), ch(b), a)


def collect_faces():
    faces = []
    for name, _parent, _pos, _rot, cubes in PARTS:
        for ox, oy, oz, w, h, d, color in cubes:
            for face_name, quad in cube_faces((ox, oy, oz), (w, h, d)):
                world = [visual(*to_model(name, p)) for p in quad]
                depth = sum(p[2] for p in world) / 4.0
                faces.append((depth, world, shade(color, face_name), name))
    return faces


def write_png(path, w, h, pixels):
    raw = bytearray()
    for y in range(h):
        raw.append(0)
        raw.extend(pixels[y * w * 4:(y + 1) * w * 4])
    def chunk(tag, data):
        return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(bytes(raw), 9)) + chunk(b"IEND", b"")
    Path(path).write_bytes(png)


def render(view, scale=14, pad=30):
    faces = collect_faces()
    # view: function (x,y,z) -> (px, py, depth)
    projected = []
    for depth, quad, color, name in faces:
        pts = [view(*p) for p in quad]
        avg_d = sum(p[2] for p in pts) / 4
        projected.append((avg_d, pts, color))
    # Larger depth is farther from the camera. Draw far faces first.
    projected.sort(key=lambda t: t[0], reverse=True)

    xs = [p[0] for _d, pts, _c in projected for p in pts]
    ys = [p[1] for _d, pts, _c in projected for p in pts]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    w = int((maxx - minx) * scale) + pad * 2
    h = int((maxy - miny) * scale) + pad * 2
    pix = bytearray([40, 44, 52, 255] * (w * h))

    def plot(x, y, color):
        if 0 <= x < w and 0 <= y < h:
            i = (y * w + x) * 4
            pix[i:i + 4] = bytes(color)

    def fill_tri(a, b, c, color):
        pts = sorted([a, b, c], key=lambda p: p[1])
        (x0, y0), (x1, y1), (x2, y2) = pts
        def edge(y, ya, xa, yb, xb):
            if yb == ya:
                return xa
            t = (y - ya) / (yb - ya)
            return xa + t * (xb - xa)
        y_start = int(math.floor(y0))
        y_end = int(math.ceil(y2))
        for y in range(y_start, y_end + 1):
            if y < y1:
                xa = edge(y, y0, x0, y1, x1)
                xb = edge(y, y0, x0, y2, x2)
            else:
                xa = edge(y, y1, x1, y2, x2)
                xb = edge(y, y0, x0, y2, x2)
            if xa > xb:
                xa, xb = xb, xa
            for x in range(int(math.floor(xa)), int(math.ceil(xb)) + 1):
                plot(x, y, color)

    for _d, pts, color in projected:
        screen = []
        for x, y, _z in pts:
            sx = pad + (x - minx) * scale
            # image y down
            sy = pad + (maxy - y) * scale
            screen.append((sx, sy))
        fill_tri(screen[0], screen[1], screen[2], color)
        fill_tri(screen[0], screen[2], screen[3], color)
    return w, h, pix


def front(x, y, z):
    # look from -Z (face). After visual(), entity front is -Z model which is vz = mz.
    # model front cubes have smaller mz. visual z = mz. So face is at smaller z.
    # Camera looks along +Z? We want to see the face, so depth = z (larger z = farther if face is -z).
    return (x, y, z)


def side(x, y, z):
    # from the entity's left, +X visual? visual x is flipped model x.
    # Show side: horizontal axis is z (front to the left), depth is x.
    return (-z, y, x)


def three_quarter(x, y, z):
    yaw = math.radians(35)
    ca, sa = math.cos(yaw), math.sin(yaw)
    rx = x * ca - z * sa
    rz = x * sa + z * ca
    return (rx, y, rz)


def main():
    samples = {
        "nose": ("nose", (0, 0, -0.7)),
        "tail tip": ("tail3", (0, 0, 4.0)),
        "ear tip": ("ear_l", (0, -2.6, 0)),
        "foot": ("leg_fl", (0, 3.4, 0)),
        "body top": ("body", (0, -5.6, 0)),
    }
    for label, (part, local) in samples.items():
        mx, my, mz = to_model(part, local)
        vx, vy, vz = visual(mx, my, mz)
        print(f"{label:10} model=({mx:6.1f},{my:6.1f},{mz:6.1f}) visual_y={vy:5.1f} z={vz:5.1f}")

    out = Path("/workspace/preview")
    out.mkdir(exist_ok=True)
    for name, view in (("front", front), ("side", side), ("threeq", three_quarter)):
        w, h, pix = render(view)
        write_png(out / f"lucky_{name}.png", w, h, pix)
        print(name, w, h)


if __name__ == "__main__":
    main()
